# Smart Warehouse AGV Dispatcher

A Python-based warehouse simulation that demonstrates **intelligent task allocation and pathfinding for a fleet of Automated Guided Vehicles (AGVs)**. The project combines the **Hungarian Algorithm** for assigning orders with **A\*** for route planning, and provides a live dashboard built with Pygame.

The AGVs are heterogeneous: each has its own movement speed, maximum load capacity, energy consumption rate, and time-based operating cost. Orders can arrive dynamically, and the simulator tracks operational performance while handling basic robot-to-robot blocking and deadlocks.

## Features

- **Multiple AGVs:** Four robots with different speeds, load limits, energy rates, and operating-cost rates.
- **Task allocation strategies:**
  - **FCFS:** assigns the oldest pending order to the AGV expected to become available first.
  - **Nearest:** assigns the oldest pending order to the closest available AGV.
  - **Hungarian:** uses a global cost-minimizing assignment based on estimated completion time, operating cost, and existing workload.
- **A\* pathfinding:** plans routes through the warehouse grid.
- **Dynamic order handling:** create individual orders, generate batches of random orders, or import orders from a CSV file.
- **Live Pygame dashboard:** visualize the warehouse, AGVs, routes, order activity, and simulation metrics.
- **Collision avoidance:** AGVs reserve their next cell before moving so two robots cannot enter the same cell or swap positions.
- **Basic deadlock handling:** blocked AGVs can request alternate routes; idle robots can move aside, and a back-off mechanism helps resolve persistent stand-offs.
- **Strategy comparison:** run the same workload under different dispatching strategies and compare the results.
- **Tests:** core simulation and algorithm behavior is covered by the test suite.

## Project structure

```text
smart_warehouse/
├── main.py
├── dashboard.py
├── compare.py
├── requirements.txt
├── README.md
├── data/
│   └── sample_orders.csv
├── tests/
│   └── test_core.py
└── warehouse/
    ├── __init__.py
    ├── astar.py
    ├── config.py
    ├── grid.py
    ├── hungarian.py
    ├── models.py
    ├── orders_io.py
    ├── simulation.py
    └── strategies.py
```

| File | Purpose |
|---|---|
| `main.py` | Starts the graphical dashboard. |
| `dashboard.py` | Pygame interface, controls, visualization, and user interaction. |
| `compare.py` | Runs headless experiments and compares dispatching strategies. |
| `warehouse/grid.py` | Defines the warehouse grid, shelves, pickup points, and delivery points. |
| `warehouse/astar.py` | A\* pathfinding implementation. |
| `warehouse/hungarian.py` | Hungarian assignment algorithm implementation. |
| `warehouse/models.py` | AGV and order data models. |
| `warehouse/strategies.py` | FCFS, Nearest, Hungarian assignment, and cost-matrix construction. |
| `warehouse/simulation.py` | Simulation engine, dispatching, movement, collision handling, and metrics. |
| `warehouse/orders_io.py` | CSV import/export and random order generation. |
| `warehouse/config.py` | Simulation constants, strategy presets, and configurable values. |
| `tests/test_core.py` | Automated tests for core functionality. |

## Requirements

- Python 3.10 or newer recommended
- `pygame-ce` for the dashboard
- `matplotlib` for optional comparison charts
- `pytest` for running the tests

Install dependencies from the project directory:

```bash
pip install -r requirements.txt
```

If you only want to run the dashboard, install Pygame Community Edition:

```bash
pip install pygame-ce
```

## Run the project

Open a terminal and move into the `smart_warehouse` directory:

```bash
cd smart_warehouse
```

### 1. Launch the dashboard

```bash
python main.py
```

The dashboard loads the sample orders from `data/sample_orders.csv` when the file is available.

### 2. Compare allocation strategies

```bash
python compare.py
```

By default, the comparison runs 30 randomly generated orders using the same warehouse, AGVs, and order workload for each configuration.

Useful options:

```bash
# Run 60 orders with a fixed random seed
python compare.py --orders 60 --seed 7

# Spread order arrivals over the next 200 simulated seconds
python compare.py --orders 60 --seed 7 --spread 200

# Use a CSV workload instead of random orders
python compare.py --csv data/sample_orders.csv

# Save the comparison table to CSV
python compare.py --out results.csv

# Also generate a comparison chart (requires matplotlib)
python compare.py --out results.csv --chart
```

### 3. Run tests

Using pytest:

```bash
pytest
```

Or run the test file directly:

```bash
python tests/test_core.py
```

## Using the dashboard

The dashboard provides controls for starting and managing the simulation:

- **Start / Pause / Resume:** control simulation execution.
- **Reset:** restore the initial simulation state and reload the sample orders.
- **New Order:** enter an individual order.
- **Generate:** add a batch of randomly generated orders.
- **Import CSV:** load orders from a CSV file.
- **Export:** export the current orders and their outcomes to `orders_export.csv`.
- **AGV selection:** select an AGV card to highlight that robot and its route.
- **Strategy selection:** switch between FCFS, Nearest, and Hungarian allocation.
- **Weight controls:** adjust the time, energy, and workload weights used by the Hungarian strategy.

Keyboard shortcuts:

| Key | Action |
|---|---|
| `Space` | Start, pause, or resume |
| `R` | Reset the simulation |
| `N` | Open the New Order dialog |
| `G` | Generate random orders |
| `I` | Import orders from CSV |
| `Esc` | Close a dialog or exit |

The playback-speed setting controls the speed of the animation. It does **not** change an AGV's configured movement speed.

## AGV configuration

The default simulation uses four AGVs:

| AGV | Speed (cells/s) | Maximum load | Energy per cell | Time cost (₹/s) |
|---|---:|---:|---:|---:|
| AGV-01 | 2.0 | 100 kg | 0.5 | 0.30 |
| AGV-02 | 3.0 | 60 kg | 0.8 | 0.45 |
| AGV-03 | 1.5 | 150 kg | 0.4 | 0.35 |
| AGV-04 | 2.5 | 80 kg | 0.6 | 0.40 |

A loaded AGV can consume up to 30% more energy per cell. The default loading and unloading time is 3 simulated seconds.

These values can be changed in `default_agvs()` in `warehouse/simulation.py` and in `warehouse/config.py`.

## How task allocation works

When an order arrives, it is placed in the pending queue. The dispatcher considers AGVs that have room for another assignment and selects one of the configured allocation strategies.

### FCFS

Orders are considered from oldest to newest. Each order is assigned to the eligible AGV with the least estimated remaining workload.

### Nearest

Orders are considered from oldest to newest. Each order is assigned to the eligible AGV closest to its pickup location. This strategy does not account for differences in AGV speed.

### Hungarian Algorithm

The Hungarian strategy builds a cost matrix for pending orders and eligible AGVs. It then finds a minimum-cost matching rather than making each assignment independently.

The assignment cost is:

```text
Cost(AGV, Order) = α × T + β × E + γ × W
```

Where:

- **T — Estimated completion time:** estimated travel time for the pickup and delivery legs, using that AGV's speed, plus handling time.
- **E — Estimated operating cost:** estimated energy cost plus the AGV's time-based operating cost.
- **W — Existing workload:** estimated time the AGV needs to finish its current and already queued work.

The time, energy-cost, and workload values are normalized before applying the weights, so values with different units can be combined meaningfully. An order that exceeds an AGV's load capacity is treated as infeasible for that AGV.

The available weight presets are:

| Preset | Time (α) | Energy (β) | Workload (γ) |
|---|---:|---:|---:|
| Time | 0.70 | 0.10 | 0.20 |
| Energy | 0.10 | 0.70 | 0.20 |
| Balanced | 0.40 | 0.30 | 0.30 |

The sliders in the dashboard allow the weights to be adjusted.

## Pathfinding and robot coordination

### A\* pathfinding

Each AGV uses A\* to find a path from its current cell to the next target. The path planner works on the warehouse grid and can avoid cells occupied by other AGVs when calculating an alternate route.

### Collision avoidance

The simulator uses basic cell reservation:

1. An AGV requests/reserves its next cell before moving.
2. A cell occupied by another AGV or reserved by another AGV cannot be entered.
3. AGVs take movement turns in a deterministic priority order, preventing two robots from claiming the same free cell in one step.
4. An AGV cannot swap directly into another AGV's current cell while that AGV is trying to move into its cell.

### Deadlock handling

When an AGV remains blocked, the simulator can attempt an alternate A\* route. Idle AGVs may move aside when their position blocks another robot. A back-off mechanism is also used for persistent stand-offs.

This is intentionally a **basic coordination approach**, not a full multi-agent pathfinding (MAPF) algorithm. Planned task times and costs are estimates and do not include all delays caused by congestion.

## Order CSV format

The CSV file must contain these columns:

```csv
pickup,delivery,weight,arrival
P2,D1,50,0
P1,D3,40,10
```

- `pickup`: pickup-point identifier.
- `delivery`: delivery-point identifier.
- `weight`: order weight in kilograms.
- `arrival`: optional arrival time in simulated seconds after import.

The pickup and delivery identifiers must exist in the selected warehouse layout. Invalid rows are skipped and reported. The `arrival` column is optional.

## Performance metrics

The simulator and comparison script report metrics such as:

- Number of completed and pending orders
- Average order completion time
- Total distance travelled
- Empty-travel distance
- Energy consumed
- Estimated operating cost
- AGV utilization
- Workload balance
- Time spent blocked by other AGVs

The comparison script evaluates these configurations on the same input workload:

1. FCFS
2. Nearest
3. Hungarian — Time preset
4. Hungarian — Energy preset
5. Hungarian — Balanced preset

This makes the comparison more meaningful because each strategy is tested against the same orders and starting conditions.

## Customization

- **Change AGV properties:** edit `default_agvs()` in `warehouse/simulation.py`.
- **Change simulation parameters:** edit `warehouse/config.py`.
- **Change the warehouse layout:** modify the default layout in `warehouse/grid.py` or create a compatible layout file and load it using `Grid.from_file(...)`.
- **Change sample orders:** edit `data/sample_orders.csv`.
- **Add an allocation strategy:** implement it in `warehouse/strategies.py` and register it in `STRATEGY_FUNCTIONS`.

## Scope and limitations

- The project models task allocation, grid-based pathfinding, heterogeneous AGVs, and basic collision/deadlock handling.
- It does not implement advanced multi-agent pathfinding or globally optimal collision-free route planning.
- Travel-time and operating-cost estimates may differ from final results because real movement can be delayed by other AGVs.
- The energy model is a simplified consumption and cost estimate, not a detailed physical battery model.

## Authors

**Team 11**

- Ratan Kumar Mahato (2501AI18)
- Anubhav Kumar (2501AI05)
- Jitesh Kumar (2501AI29)
- Devansh Yadav (2501AI25)
- Devesh Yadav (2501AI38)
- Aman Raj (2501AI46)
- Chitra Sandilya (2501CS20)
- Riya Raj (2501AI22)
- Aniska Saha (2503CS04)
