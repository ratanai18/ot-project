"""Pygame dashboard for the Smart Warehouse AGV Dispatcher.

Every number on screen comes from the running simulation (warehouse/simulation.py).
This file only draws things and reacts to clicks.

Two different "speeds" exist and are kept apart:
  * AGV speed      - cells per second, a property of each robot (affects task times)
  * Playback speed - Slow / Normal / Fast, how fast the animation runs on your screen
"""
import math
import os
import random
import sys

import pygame

if sys.platform == "win32":          # without this Windows blurs the window on scaled displays
    try:
        import ctypes
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

from warehouse import config
from warehouse.orders_io import export_orders_csv, load_orders_csv, random_orders
from warehouse.simulation import default_simulation

W, H = 1760, 1012
HERE = os.path.dirname(os.path.abspath(__file__))
SAMPLE_CSV = os.path.join(HERE, "data", "sample_orders.csv")
EXPORT_CSV = os.path.join(HERE, "orders_export.csv")

# ---- colours ------------------------------------------------------------
BG = (9, 19, 36)
PANEL = (15, 30, 52)
PANEL2 = (20, 38, 64)
BORDER = (32, 52, 80)
TEXT = (235, 240, 248)
MUTED = (140, 158, 182)
BLUE = (37, 99, 235)
LBLUE = (96, 165, 250)
CYAN = (34, 211, 238)
GREEN = (34, 197, 94)
RED = (220, 38, 38)
ORANGE = (249, 115, 22)
YELLOW = (250, 204, 21)
PURPLE = (139, 92, 246)
PINK = (236, 72, 153)
SHELF = (104, 116, 132)
WHITE = (255, 255, 255)

STATUS_COLOURS = {"Idle": (148, 163, 184), "To Pickup": LBLUE, "Delivering": GREEN, "Waiting": YELLOW,
                  "Blocked": ORANGE, "Moving aside": (148, 163, 184)}
# order status -> (badge background, badge text)
ORDER_BADGES = {"Pending": ((122, 88, 26), (252, 211, 77)),
                "Assigned": (BLUE, WHITE),
                "In Progress": ((22, 101, 52), (134, 239, 172)),
                "Completed": ((21, 128, 61), WHITE),
                "Failed": ((153, 27, 27), (254, 202, 202))}
LOG_COLOURS = {"green": GREEN, "blue": LBLUE, "orange": ORANGE, "purple": PURPLE,
               "pink": PINK, "red": RED}

# ---- layout (design units; the window scales everything to fit) -------------
CELL = 44
MAP_X, MAP_Y = 346, 132
ORDER_ROWS = 6
LOG_ROWS = 7
WEIGHT_ROWS = [("alpha", "Time (\u03b1)"), ("beta", "Energy (\u03b2)"), ("gamma", "Workload (\u03b3)")]


class Painter:
    """Draws shapes given in design units (1760 x 1012) at the real window resolution.

    Same function names as pygame.draw, so the drawing code stays simple. Nothing is ever
    drawn small and stretched, so lines and text stay sharp at any window size.
    """

    def __init__(self):
        self.surface = None
        self.scale = 1.0
        self.ox = 0.0
        self.oy = 0.0

    def setup(self, surface, scale, ox, oy):
        self.surface, self.scale, self.ox, self.oy = surface, scale, ox, oy

    def px(self, value):
        return int(round(value * self.scale))

    def pt(self, point):
        return (int(round(point[0] * self.scale + self.ox)), int(round(point[1] * self.scale + self.oy)))

    def width(self, w):
        return 0 if w == 0 else max(1, self.px(w))

    def to_rect(self, r):
        x, y, w, h = r
        left, top = self.pt((x, y))
        right, bottom = self.pt((x + w, y + h))
        return pygame.Rect(left, top, max(1, right - left), max(1, bottom - top))

    def rect(self, _surface, colour, r, width=0, border_radius=0):
        pygame.draw.rect(self.surface, colour, self.to_rect(r), self.width(width),
                         border_radius=self.px(border_radius))

    def circle(self, _surface, colour, center, radius, width=0):
        pygame.draw.circle(self.surface, colour, self.pt(center), max(1, self.px(radius)), self.width(width))

    def line(self, _surface, colour, a, b, width=1):
        pygame.draw.line(self.surface, colour, self.pt(a), self.pt(b), self.width(width))

    def lines(self, _surface, colour, closed, points, width=1):
        pygame.draw.lines(self.surface, colour, closed, [self.pt(p) for p in points], self.width(width))

    def polygon(self, _surface, colour, points, width=0):
        pygame.draw.polygon(self.surface, colour, [self.pt(p) for p in points], self.width(width))

    def arc(self, _surface, colour, r, start, stop, width=1):
        pygame.draw.arc(self.surface, colour, self.to_rect(r), start, stop, self.width(width))


paint = Painter()


def fmt_time(seconds):
    s = int(seconds)
    return f"{s // 3600:02d}:{s % 3600 // 60:02d}:{s % 60:02d}"


def status_of(agv):
    """The status shown on screen: waiting for another AGV counts as 'Blocked'."""
    if agv.blocked:
        return "Blocked"
    return "Moving aside" if agv.status == "Yielding" else agv.status


def lighten(colour, amount=22):
    return tuple(min(255, c + amount) for c in colour)


class Dashboard:
    def __init__(self):
        os.environ.setdefault("SDL_VIDEO_CENTERED", "1")
        pygame.init()
        pygame.display.set_caption("Smart Warehouse AGV Dispatcher")

        # The window starts at a size that fits your screen. Everything is laid out in
        # 1760x1012 "design units" and drawn at the real window size (see Painter above).
        info = pygame.display.Info()
        scale = min(info.current_w * 0.96 / W, info.current_h * 0.86 / H)
        pygame.display.set_mode((int(W * scale), int(H * scale)), pygame.RESIZABLE)
        self.screen = pygame.display.get_surface()
        self.view = (0, 0, scale)     # (x offset, y offset, scale) of the layout inside the window

        names = "segoeui,helveticaneue,helvetica,arial,dejavusans"
        sizes = {"title": (26, True), "h2": (22, True), "h3": (19, True), "value": (22, True),
                 "body": (17, False), "small": (15, False), "tiny": (13, False),
                 "tinybold": (13, True)}
        self.font_names = names
        self.font_sizes = sizes
        self.fonts = {}
        self.font_scale = None

        self.strategy = "Hungarian"
        self.weights = dict(config.PRESETS["Balanced"])
        self.playback = 1             # index into config.PLAYBACK
        self.gen_count = 10
        self.mouse = (0, 0)
        self.buttons = []
        self.sliders = []
        self.drag = None
        self.notice = ""
        self.notice_timer = 0
        self.reset()

    # ------------------------------------------------------------ state
    def reset(self):
        self.sim = default_simulation(self.strategy, self.weights)
        self.rng = random.Random()
        self.state = "ready"          # ready -> running <-> paused
        self.selected = 0
        self.order_scroll = 0
        self.modal = None
        if os.path.exists(SAMPLE_CSV):
            load_orders_csv(SAMPLE_CSV, self.sim)
        else:
            random_orders(self.sim, 5, self.rng)

    def say(self, message):
        self.notice = message
        self.notice_timer = 360

    def quit(self):
        pygame.quit()
        sys.exit()

    # ---------------------------------------------------------- actions
    def do(self, action):
        name, arg = action
        sim = self.sim
        if name == "select":
            self.selected = arg
        elif name == "toggle":
            self.state = "paused" if self.state == "running" else "running"
        elif name == "reset":
            self.reset()
        elif name == "playback":
            self.playback = arg
        elif name == "strategy":
            self.strategy = arg
            sim.set_strategy(arg)
        elif name == "preset":
            self.weights.update(config.PRESETS[arg])
            sim.set_weights(**config.PRESETS[arg])
        elif name == "gen_count":
            self.gen_count = max(1, min(50, self.gen_count + arg))
        elif name == "generate":
            made = random_orders(sim, self.gen_count, self.rng)
            self.say(f"Generated {len(made)} random orders")
        elif name == "import":
            self.import_csv()
        elif name == "export":
            count = export_orders_csv(EXPORT_CSV, sim)
            self.say(f"Exported {count} orders to orders_export.csv")
        elif name == "clear_log":
            sim.events.clear()
        elif name == "open_modal":
            self.modal = {"pickup": 0, "delivery": 0, "weight": 30}
        elif name == "modal_cycle":
            options = list(sim.grid.pickups if arg == "pickup" else sim.grid.deliveries)
            self.modal[arg] = (self.modal[arg] + 1) % len(options)
        elif name == "modal_weight":
            self.modal["weight"] = max(5, min(200, self.modal["weight"] + arg))
        elif name == "modal_cancel":
            self.modal = None
        elif name == "modal_create":
            m = self.modal
            try:
                order = sim.add_order(list(sim.grid.pickups)[m["pickup"]],
                                      list(sim.grid.deliveries)[m["delivery"]], m["weight"])
                self.say(f"Order #{order.id} created")
                self.modal = None
            except ValueError as err:
                self.say(str(err))

    def import_csv(self):
        path = ""
        try:                                   # a normal file-open window (tkinter ships with Python)
            import tkinter
            from tkinter import filedialog
            root = tkinter.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            path = filedialog.askopenfilename(title="Import orders from CSV",
                                              initialdir=os.path.join(HERE, "data"),
                                              filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
            root.destroy()
        except Exception:
            path = SAMPLE_CSV if os.path.exists(SAMPLE_CSV) else ""
        if not path:
            return
        try:
            added, errors = load_orders_csv(path, self.sim)
        except OSError as err:
            self.say(f"Could not read file: {err}")
            return
        message = f"Imported {len(added)} orders"
        if errors:
            message += f", skipped {len(errors)} bad rows ({errors[0]})"
        self.say(message)

    def set_slider(self, track, key, x):
        value = max(0.0, min(1.0, (x - track.x) / track.w))
        value = round(value * 20) / 20           # steps of 0.05
        if abs(value - self.weights[key]) > 1e-9:
            self.weights[key] = value
            self.sim.set_weights(**{key: value})

    # ----------------------------------------------------------- events
    def handle(self, event):
        if event.type == pygame.QUIT:
            self.quit()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = self.to_logical(event.pos)
            if not self.modal:
                for track, key in self.sliders:
                    if track.inflate(16, 24).collidepoint(pos):
                        self.drag = (track, key)
                        self.set_slider(track, key, pos[0])
                        return
            for rect, action in reversed(self.buttons):
                if rect.collidepoint(pos):
                    self.do(action)
                    break
        elif event.type == pygame.MOUSEMOTION:
            if self.drag:
                self.set_slider(self.drag[0], self.drag[1], self.to_logical(event.pos)[0])
        elif event.type == pygame.MOUSEBUTTONUP:
            self.drag = None
        elif event.type == pygame.MOUSEWHEEL:
            if pygame.Rect(1268, 84, 480, 360).collidepoint(self.mouse):
                limit = max(0, len(self.sim.orders) - ORDER_ROWS)
                self.order_scroll = max(0, min(limit, self.order_scroll + event.y))
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                if self.modal:
                    self.modal = None
                else:
                    self.quit()
            elif self.modal:
                return
            elif event.key == pygame.K_SPACE:
                self.do(("toggle", None))
            elif event.key == pygame.K_r:
                self.do(("reset", None))
            elif event.key == pygame.K_n:
                self.do(("open_modal", None))
            elif event.key == pygame.K_g:
                self.do(("generate", None))
            elif event.key == pygame.K_i:
                self.do(("import", None))

    # -------------------------------------------------------- main loop
    def run(self):
        clock = pygame.time.Clock()
        while True:
            frame = clock.tick(60) / 1000
            self.mouse = self.to_logical(pygame.mouse.get_pos())
            for event in pygame.event.get():
                self.handle(event)

            self.advance(frame)
            if self.notice_timer > 0:
                self.notice_timer -= 1
            self.draw()
            pygame.display.flip()

    def advance(self, frame):
        """Move the simulation forward by one frame of real time."""
        if self.state != "running" or self.modal:
            return
        # simulated seconds that pass during this frame = real time x playback speed
        remaining = min(frame, 0.1) * config.PLAYBACK[self.playback][1]
        while remaining > 1e-9:
            step = min(remaining, config.SIM_DT)
            self.sim.step(step)
            remaining -= step

    # ------------------------------------------------ window scaling
    def use_font_scale(self, scale):
        """Fonts are rebuilt at the real pixel size whenever the window size changes."""
        if self.font_scale is not None and abs(scale - self.font_scale) < 1e-6:
            return
        self.font_scale = scale
        self.fonts = {k: pygame.font.SysFont(self.font_names, max(8, int(round(size * scale))), bold=bold)
                      for k, (size, bold) in self.font_sizes.items()}

    def to_logical(self, pos):
        ox, oy, scale = self.view
        return ((pos[0] - ox) / scale, (pos[1] - oy) / scale)

    # ---------------------------------------------------- drawing tools
    def text(self, s, font, colour, pos, anchor="topleft"):
        surf = self.fonts[font].render(str(s), True, colour)
        rect = surf.get_rect(**{anchor: paint.pt(pos)})
        self.screen.blit(surf, rect)
        k = paint.scale          # hand back the rectangle in design units
        return pygame.Rect((rect.x - paint.ox) / k, (rect.y - paint.oy) / k, rect.w / k, rect.h / k)

    def fit(self, s, font, max_width):
        """Shorten text with '...' so it fits in max_width pixels."""
        f = self.fonts[font]
        if f.size(s)[0] / paint.scale <= max_width:
            return s
        while s and f.size(s + "...")[0] / paint.scale > max_width:
            s = s[:-1]
        return s + "..."

    def box(self, rect, colour, radius=10, border=None, width=1):
        paint.rect(self.screen, colour, rect, border_radius=radius)
        if border:
            paint.rect(self.screen, border, rect, width, border_radius=radius)

    def button(self, rect, label, colour, action, icon=None, border=None, font="body", text_colour=WHITE):
        rect = pygame.Rect(rect)
        hover = rect.collidepoint(self.mouse)
        self.box(rect, lighten(colour) if hover else colour, 8, border)
        label_w = self.fonts[font].size(label)[0] / paint.scale if label else 0
        icon_w = 22 if icon else 0
        gap = 8 if icon and label else 0
        x = rect.centerx - (label_w + icon_w + gap) / 2
        if icon:
            self.icon(icon, x + 11, rect.centery, 9, WHITE)
        if label:
            self.text(label, font, text_colour, (x + icon_w + gap, rect.centery), "midleft")
        self.buttons.append((rect, action))

    def icon(self, kind, cx, cy, s, colour=WHITE):
        """Tiny hand-drawn icons. s is roughly half the icon size."""
        d = self.screen
        if kind == "pause":
            paint.rect(d, colour, (cx - s * 0.7, cy - s, s * 0.55, s * 2), border_radius=2)
            paint.rect(d, colour, (cx + s * 0.15, cy - s, s * 0.55, s * 2), border_radius=2)
        elif kind == "play":
            paint.polygon(d, colour, [(cx - s * 0.6, cy - s), (cx - s * 0.6, cy + s), (cx + s, cy)])
        elif kind == "reset":
            paint.arc(d, colour, (cx - s, cy - s, 2 * s, 2 * s), 0.7, 5.6, 3)
            paint.polygon(d, colour, [(cx + s * 0.9, cy - s * 0.95), (cx + s * 0.2, cy - s * 0.95),
                                      (cx + s * 0.8, cy - s * 0.25)])
        elif kind == "plus":
            paint.line(d, colour, (cx - s, cy), (cx + s, cy), 3)
            paint.line(d, colour, (cx, cy - s), (cx, cy + s), 3)
        elif kind == "doc":
            paint.rect(d, colour, (cx - s * 0.75, cy - s, s * 1.5, s * 2), 2, border_radius=3)
            for k in (-0.4, 0.1, 0.6):
                paint.line(d, colour, (cx - s * 0.4, cy + k * s), (cx + s * 0.4, cy + k * s), 2)
        elif kind == "check":
            paint.lines(d, colour, False, [(cx - s * 0.7, cy), (cx - s * 0.15, cy + s * 0.6),
                                           (cx + s * 0.8, cy - s * 0.6)], 4)
        elif kind == "clock":
            paint.circle(d, colour, (cx, cy), s, 3)
            paint.lines(d, colour, False, [(cx, cy - s * 0.6), (cx, cy), (cx + s * 0.5, cy + s * 0.3)], 2)
        elif kind == "hourglass":
            paint.polygon(d, colour, [(cx - s * 0.7, cy - s), (cx + s * 0.7, cy - s), (cx, cy)])
            paint.polygon(d, colour, [(cx - s * 0.7, cy + s), (cx + s * 0.7, cy + s), (cx, cy)])
        elif kind == "road":
            paint.polygon(d, colour, [(cx - s * 0.4, cy - s), (cx + s * 0.4, cy - s),
                                      (cx + s, cy + s), (cx - s, cy + s)])
            paint.line(d, (60, 60, 70), (cx, cy - s * 0.8), (cx, cy + s * 0.8), 2)
        elif kind == "empty":                    # a dashed line with an arrow head
            for a in (-1.0, -0.35):
                paint.line(d, colour, (cx + a * s, cy), (cx + (a + 0.45) * s, cy), 3)
            paint.polygon(d, colour, [(cx + 0.3 * s, cy - 0.55 * s), (cx + s, cy), (cx + 0.3 * s, cy + 0.55 * s)])
        elif kind == "bolt":
            pts = [(0.25, -1), (-0.6, 0.1), (-0.05, 0.1), (-0.25, 1), (0.6, -0.2), (0.05, -0.2)]
            paint.polygon(d, colour, [(cx + a * s, cy + b * s) for a, b in pts])
        elif kind == "rupee":
            self.text("\u20b9", "value", colour, (cx, cy), "center")

    def robot(self, cx, cy, size, colour):
        """A little friendly robot, used on the fleet cards and on the map."""
        d = self.screen
        cx, cy = int(cx), int(cy)
        body = pygame.Rect(0, 0, size, int(size * 0.8))
        body.center = (cx, cy + int(size * 0.08))
        paint.line(d, colour, (cx, body.top), (cx, body.top - int(size * 0.2)), 2)
        paint.circle(d, colour, (cx, body.top - int(size * 0.22)), max(2, int(size * 0.07)))
        paint.rect(d, colour, body, border_radius=int(size * 0.25))
        face = pygame.Rect(0, 0, int(size * 0.74), int(size * 0.4))
        face.center = (cx, body.centery - int(size * 0.05))
        paint.rect(d, (14, 24, 44), face, border_radius=int(size * 0.14))
        for dx in (-0.17, 0.17):
            paint.circle(d, (150, 235, 255), (int(cx + dx * size), face.centery), max(2, int(size * 0.07)))
        for dx in (-0.32, 0.32):
            paint.rect(d, (14, 24, 44), (int(cx + dx * size) - 3, body.bottom - 2, 6, 5), border_radius=2)

    def cell_center(self, cell):
        return MAP_X + (cell[0] + 0.5) * CELL, MAP_Y + (cell[1] + 0.5) * CELL

    def dashed_line(self, points, colour, dash=9, gap=6, width=3):
        pattern = dash + gap
        travelled = 0.0
        for a, b in zip(points, points[1:]):
            length = math.hypot(b[0] - a[0], b[1] - a[1])
            if length == 0:
                continue
            ux, uy = (b[0] - a[0]) / length, (b[1] - a[1]) / length
            t = 0.0
            while t < length:
                phase = (travelled + t) % pattern
                if phase < dash:
                    run = min(dash - phase, length - t)
                    p1 = (a[0] + ux * t, a[1] + uy * t)
                    p2 = (a[0] + ux * (t + run), a[1] + uy * (t + run))
                    paint.line(self.screen, colour, p1, p2, width)
                    t += run
                else:
                    t += pattern - phase
            travelled += length

    def panel(self, rect, title=None, font="h2"):
        self.box(rect, PANEL, 12, BORDER)
        if title:
            self.text(title, font, TEXT, (rect[0] + 16, rect[1] + 22), "midleft")

    # ------------------------------------------------------------ draw
    def draw(self):
        self.buttons = []
        self.sliders = []
        self.screen = pygame.display.get_surface()
        window_w, window_h = self.screen.get_size()
        scale = min(window_w / W, window_h / H)
        self.view = ((window_w - W * scale) / 2, (window_h - H * scale) / 2, scale)
        paint.setup(self.screen, scale, self.view[0], self.view[1])
        self.use_font_scale(scale)
        self.screen.fill(BG)

        self.draw_header()
        self.draw_fleet()
        self.draw_map()
        self.draw_orders()
        self.draw_optimization()
        self.draw_log()
        self.draw_analytics()
        self.draw_footer()
        if self.modal:
            self.draw_modal()

    def draw_header(self):
        d = self.screen
        paint.rect(d, PANEL, (0, 0, W, 72))
        paint.line(d, BORDER, (0, 72), (W, 72), 1)

        paint.polygon(d, CYAN, [(20, 36), (44, 14), (68, 36)])
        paint.rect(d, LBLUE, (26, 36, 36, 24), border_radius=3)
        paint.rect(d, PANEL, (38, 44, 12, 16))
        self.text("SMART WAREHOUSE AGV DISPATCHER", "title", WHITE, (84, 36), "midleft")

        self.text("Status", "small", MUTED, (720, 10))
        label, colour = {"ready": ("Ready", YELLOW), "running": ("Running", GREEN),
                         "paused": ("Paused", ORANGE)}[self.state]
        paint.circle(d, colour, (730, 46), 8)
        self.text(label, "h3", colour, (746, 46), "midleft")

        self.text("Simulation Clock", "small", MUTED, (880, 10))
        self.text(self.sim.clock(), "h2", WHITE, (880, 30))

        self.text("Playback speed", "small", MUTED, (1050, 10))
        for i, (name, factor) in enumerate(config.PLAYBACK):
            active = i == self.playback
            self.button((1050 + i * 98, 32, 94, 32), f"{name} {factor:g}x", BLUE if active else PANEL2,
                        ("playback", i), border=None if active else BORDER, font="small")

        text, icon, colour = {"ready": ("Start", "play", BLUE), "running": ("Pause", "pause", (180, 100, 20)),
                              "paused": ("Resume", "play", BLUE)}[self.state]
        self.button((1450, 14, 140, 44), text, colour, ("toggle", None), icon=icon)
        self.button((1604, 14, 134, 44), "Reset", RED, ("reset", None), icon="reset")

    def draw_fleet(self):
        self.panel((12, 84, 292, 796), f"AGV Fleet ({len(self.sim.agvs)})")
        for i, agv in enumerate(self.sim.agvs):
            y = 138 + i * 182
            rect = pygame.Rect(20, y, 276, 170)
            selected = i == self.selected
            self.box(rect, PANEL2, 10, CYAN if selected else BORDER, 2 if selected else 1)
            self.buttons.append((rect, ("select", i)))

            self.robot(56, y + 50, 50, agv.color)
            self.text(agv.name, "h3", WHITE, (100, y + 16))
            status = status_of(agv)
            status_rect = self.text(status, "small", STATUS_COLOURS[status], (286, y + 30), "midright")
            paint.circle(self.screen, STATUS_COLOURS[status], (status_rect.left - 11, y + 30), 6)

            order = "None"
            if agv.order:
                order = f"#{agv.order.id}  {agv.order.pickup} \u2192 {agv.order.delivery}"
                if agv.queue:
                    order += f"  (+{len(agv.queue)})"
            lines = [f"Speed: {agv.speed:.1f} cells/s",
                     f"Load: {agv.load:g} / {agv.max_load} kg",
                     f"Order: {order}",
                     f"Cost: \u20b9{agv.operating_cost:.1f}"]
            for k, line in enumerate(lines):
                self.text(self.fit(line, "small", 180), "small", MUTED if k in (0, 3) else TEXT, (100, y + 66 + k * 26))

    def draw_map(self):
        d = self.screen
        grid = self.sim.grid
        self.panel((316, 84, 940, 796), "Warehouse Map")

        area = pygame.Rect(MAP_X, MAP_Y, grid.cols * CELL, grid.rows * CELL)
        paint.rect(d, (26, 42, 62), area)
        for c in range(grid.cols + 1):
            paint.line(d, (36, 54, 76), (MAP_X + c * CELL, MAP_Y), (MAP_X + c * CELL, area.bottom))
        for r in range(grid.rows + 1):
            paint.line(d, (36, 54, 76), (MAP_X, MAP_Y + r * CELL), (area.right, MAP_Y + r * CELL))

        for (c, r) in grid.obstacles:
            cell = pygame.Rect(MAP_X + c * CELL + 1, MAP_Y + r * CELL + 1, CELL - 2, CELL - 2)
            paint.rect(d, SHELF, cell, border_radius=3)
            paint.rect(d, (88, 99, 115), cell, 1, border_radius=3)

        for name, cell in grid.pickups.items():
            self.station(cell, name, BLUE)
        for name, cell in grid.deliveries.items():
            self.station(cell, name, GREEN)

        selected = self.sim.agvs[self.selected]
        if selected.order:                       # highlight where the selected robot is heading
            heading = selected.order.pickup if selected.order.status == "Assigned" else selected.order.delivery
            target = grid.pickups.get(heading) or grid.deliveries[heading]
            cx, cy = self.cell_center(target)
            paint.circle(d, selected.color, (cx, cy), 27, 3)
            self.text(f"{selected.name} \u2192 {heading}", "small", selected.color, (1240, 106), "midright")
        else:
            self.text(f"{selected.name} selected", "small", selected.color, (1240, 106), "midright")

        for agv in self.sim.agvs:                # planned routes first, robots on top
            if agv.path:
                points = [self.cell_center(agv.xy())] + [self.cell_center(c) for c in agv.path]
                self.dashed_line(points, agv.color, width=4 if agv is selected else 3)

        for agv in self.sim.agvs:
            x, y = self.cell_center(agv.xy())
            if agv is selected:
                paint.circle(d, WHITE, (x, y), 26, 2)
            self.robot(x, y, 34, agv.color)
            if agv.load:                         # small box on top = carrying a package
                paint.rect(d, (214, 160, 90), (x + 7, y - 23, 13, 13), border_radius=2)
            if agv.blocked:                      # orange mark = waiting for another AGV
                paint.circle(d, ORANGE, (x - 15, y - 17), 7)
                self.text("!", "tinybold", (40, 20, 0), (x - 15, y - 17), "center")
            self.text(agv.name, "tinybold", WHITE, (x, y + 22), "midtop")

        ly = 858
        for x, label, colour in [(340, "Shelf", SHELF), (430, "Pickup", BLUE), (520, "Delivery", GREEN)]:
            paint.rect(d, colour, (x, ly - 10, 20, 20), border_radius=5)
            self.text(label, "small", TEXT, (x + 28, ly), "midleft")
        for i, agv in enumerate(self.sim.agvs):
            paint.circle(d, agv.color, (650 + i * 76, ly), 7)
            self.text(agv.name, "small", TEXT, (664 + i * 76, ly), "midleft")
        self.dashed_line([(990, ly), (1030, ly)], LBLUE, 8, 5, 3)
        self.text("Route", "small", TEXT, (1040, ly), "midleft")
        paint.circle(d, ORANGE, (1130, ly), 7)
        self.text("Blocked", "small", TEXT, (1144, ly), "midleft")

    def station(self, cell, name, colour):
        cx, cy = self.cell_center(cell)
        box = pygame.Rect(0, 0, 30, 30)
        box.center = (int(cx), int(cy))
        paint.rect(self.screen, colour, box, border_radius=6)
        self.text(name, "tinybold", WHITE, (cx, cy), "center")      # the name sits inside the box

    def draw_orders(self):
        orders = self.sim.orders
        pending = [o for o in orders if o.status == "Pending"]
        self.panel((1268, 84, 480, 360), f"Orders ({len(orders)})")
        self.button((1614, 98, 120, 34), "New Order", BLUE, ("open_modal", None), icon="plus", font="small")

        # bulk generation, CSV import and export
        self.button((1282, 142, 32, 32), "-", PANEL2, ("gen_count", -5 if self.gen_count > 5 else -1), border=BORDER)
        self.text(self.gen_count, "body", WHITE, (1340, 158), "center")
        self.button((1366, 142, 32, 32), "+", PANEL2, ("gen_count", 5 if self.gen_count >= 5 else 1), border=BORDER)
        self.button((1408, 142, 94, 32), "Generate", PANEL2, ("generate", None), border=BORDER, font="small")
        self.button((1510, 142, 100, 32), "Import CSV", PANEL2, ("import", None), border=BORDER, font="small")
        self.button((1618, 142, 112, 32), "Export", PANEL2, ("export", None), border=BORDER, font="small")

        # pending queue: orders no AGV has been given yet
        self.text(f"Pending queue ({len(pending)})", "small", MUTED, (1282, 198), "midleft")
        if not pending:
            self.text("empty", "small", MUTED, (1440, 198), "midleft")
        for i, order in enumerate(pending[:4]):
            chip = pygame.Rect(1440 + i * 60, 186, 56, 24)
            self.box(chip, ORDER_BADGES["Pending"][0], 5)
            self.text(f"#{order.id}", "tiny", ORDER_BADGES["Pending"][1], chip.center, "center")
        if len(pending) > 4:
            self.text(f"+{len(pending) - 4}", "small", ORDER_BADGES["Pending"][1], (1734, 198), "midright")

        paint.rect(self.screen, (12, 24, 42), (1276, 222, 464, 26), border_radius=6)
        columns = [("ID", 1286), ("Pickup", 1344), ("Delivery", 1412), ("Weight", 1492), ("AGV", 1566), ("Status", 1642)]
        for label, x in columns:
            self.text(label, "tiny", TEXT, (x, 235), "midleft")

        if not orders:
            self.text("No orders yet - add one, generate some, or import a CSV", "small", MUTED, (1508, 340), "center")
            return
        end = len(orders) - self.order_scroll
        for i, order in enumerate(orders[max(0, end - ORDER_ROWS):end]):
            y = 252 + i * 30
            cy = y + 15
            paint.line(self.screen, BORDER, (1276, y + 29), (1740, y + 29), 1)
            self.text(f"#{order.id}", "small", WHITE, (1286, cy), "midleft")
            self.text(order.pickup, "small", TEXT, (1346, cy), "midleft")
            self.text(order.delivery, "small", GREEN, (1414, cy), "midleft")
            self.text(f"{order.weight:g} kg", "small", TEXT, (1492, cy), "midleft")
            self.text(order.agv or "-", "tiny", TEXT, (1566, cy), "midleft")
            bg, fg = ORDER_BADGES[order.status]
            badge = pygame.Rect(1634, y + 3, 100, 24)
            self.box(badge, bg, 5)
            self.text(order.status, "tiny", fg, badge.center, "center")

    def draw_optimization(self):
        d = self.screen
        self.panel((1268, 456, 480, 180), "Optimization", "h3")
        hungarian = self.sim.strategy == "Hungarian"

        for name, x, w in [("Time", 1478, 62), ("Energy", 1546, 72), ("Balanced", 1624, 86)]:
            same = all(abs(self.weights[k] - v) < 1e-9 for k, v in config.PRESETS[name].items())
            self.button((x, 464, w, 26), name, BLUE if same else PANEL2, ("preset", name),
                        border=None if same else BORDER, font="tiny")

        for i, name in enumerate(config.STRATEGIES):
            active = name == self.strategy
            self.button((1284 + i * 152, 500, 148, 30), name, BLUE if active else PANEL2, ("strategy", name),
                        border=None if active else BORDER, font="small")

        for i, (key, label) in enumerate(WEIGHT_ROWS):
            y = 566 + i * 28
            self.text(label, "small", TEXT if hungarian else MUTED, (1284, y), "midleft")
            track = pygame.Rect(1410, y - 3, 250, 6)
            paint.rect(d, (40, 58, 85), track, border_radius=3)
            value = self.weights[key]
            fill = CYAN if hungarian else (80, 100, 125)
            if value > 0:
                paint.rect(d, fill, (track.x, track.y, track.w * value, track.h), border_radius=3)
            paint.circle(d, WHITE, (track.x + track.w * value, y), 9)
            paint.circle(d, fill, (track.x + track.w * value, y), 9, 2)
            self.text(f"{value:.2f}", "small", TEXT if hungarian else MUTED, (1676, y), "midleft")
            self.sliders.append((track, key))

    def draw_log(self):
        self.panel((1268, 648, 480, 232), "Event Log", "h3")
        self.button((1662, 654, 74, 26), "Clear", PANEL2, ("clear_log", None), border=BORDER, font="tiny")
        for i, (when, colour, message) in enumerate(reversed(self.sim.events[-LOG_ROWS:])):
            y = 708 + i * 26
            paint.line(self.screen, BORDER, (1276, y + 13), (1740, y + 13), 1)
            self.text(fmt_time(when), "tiny", MUTED, (1284, y), "midleft")
            paint.circle(self.screen, LOG_COLOURS.get(colour, LBLUE), (1356, y), 5)
            self.text(self.fit(message, "tiny", 360), "tiny", TEXT, (1370, y), "midleft")

    def draw_analytics(self):
        self.panel((12, 892, 1736, 96), "Performance Analytics", "h3")
        m = self.sim.metrics()
        cards = [
            ("Total Orders", f"{m['total']}", "doc", (37, 99, 235)),
            ("Completed Orders", f"{m['completed']}", "check", (34, 197, 94)),
            ("Pending Orders", f"{m['pending']}", "clock", (234, 179, 8)),
            ("Avg. Completion Time", f"{m['avg_time']:.1f} s", "hourglass", (139, 92, 246)),
            ("Total Distance", f"{m['distance']:.0f} cells", "road", (244, 63, 94)),
            ("Empty Travel", f"{m['empty_distance']:.0f} cells", "empty", (14, 165, 233)),
            ("Energy Consumed", f"{m['energy']:.1f} units", "bolt", (22, 163, 74)),
            ("Operating Cost", f"\u20b9{m['cost']:.1f}", "rupee", (249, 115, 22)),
        ]
        for i, (label, value, icon, colour) in enumerate(cards):
            x = 24 + i * 216
            self.box((x, 920, 206, 60), PANEL2, 10, BORDER)
            tile = pygame.Rect(x + 9, 930, 40, 40)
            self.box(tile, colour, 9)
            self.icon(icon, tile.centerx, tile.centery, 10, WHITE)
            self.text(label, "tiny", MUTED, (x + 58, 930))
            self.text(self.fit(value, "value", 140), "value", WHITE, (x + 58, 946))

    def draw_footer(self):
        hint = ("Space start/pause  |  R reset  |  N new order  |  G generate  |  I import CSV  |  "
                "Esc quit  |  click an AGV card to follow it on the map")
        self.text(hint, "tiny", MUTED, (16, 1000), "midleft")
        if self.notice_timer > 0:
            self.text(self.notice, "small", YELLOW, (W - 16, 1000), "midright")

    def draw_modal(self):
        shade = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 160))
        self.screen.blit(shade, (0, 0))
        self.buttons = []                      # only the pop-up reacts while it is open

        box = pygame.Rect(660, 300, 440, 390)
        self.box(box, PANEL, 14, CYAN, 2)
        self.text("New Order", "h2", WHITE, (box.x + 28, box.y + 34), "midleft")

        sim, m = self.sim, self.modal
        rows = [("Pickup", list(sim.grid.pickups)[m["pickup"]], "pickup"),
                ("Delivery", list(sim.grid.deliveries)[m["delivery"]], "delivery")]
        y = box.y + 100
        for label, value, key in rows:
            self.text(label, "body", MUTED, (box.x + 28, y), "midleft")
            self.button((box.x + 200, y - 20, 210, 40), value, PANEL2, ("modal_cycle", key), border=BORDER)
            y += 66
        self.text("Weight", "body", MUTED, (box.x + 28, y), "midleft")
        self.button((box.x + 200, y - 20, 44, 40), "-", PANEL2, ("modal_weight", -5), border=BORDER)
        self.text(f"{m['weight']} kg", "body", WHITE, (box.x + 305, y), "center")
        self.button((box.x + 366, y - 20, 44, 40), "+", PANEL2, ("modal_weight", 5), border=BORDER)

        self.text("Click a value to change it", "tiny", MUTED, (box.x + 28, box.y + 300), "midleft")
        self.button((box.x + 28, box.bottom - 70, 180, 46), "Create", BLUE, ("modal_create", None))
        self.button((box.x + 232, box.bottom - 70, 180, 46), "Cancel", PANEL2, ("modal_cancel", None), border=BORDER)


def main():
    Dashboard().run()


if __name__ == "__main__":
    main()
