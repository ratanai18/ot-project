"""Run with:  pytest      (or:  python tests/test_core.py  if you don't have pytest)"""
import csv
import os
import random
import sys
import tempfile

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, ROOT)

import compare
from warehouse import config
from warehouse.astar import astar
from warehouse.grid import Grid
from warehouse.hungarian import hungarian
from warehouse.models import AGV
from warehouse.orders_io import export_orders_csv, load_orders_csv, random_orders
from warehouse.simulation import Simulation, default_simulation

WHITE = (255, 255, 255)


def run(sim, limit=20000):
    while not sim.is_finished() and sim.time < limit:
        sim.step()
    return sim


def raises(exc, fn, *args):
    try:
        fn(*args)
    except exc:
        return True
    return False


def two_robot_sim(layout, a_pos, b_pos, strategy="Hungarian", weights=None, **b_kwargs):
    """A tiny warehouse with two hand-made robots, for precise scenarios."""
    a_args = dict(speed=2.0, max_load=100, energy_rate=0.5, time_cost=0.3)
    b_args = dict(speed=2.0, max_load=100, energy_rate=0.5, time_cost=0.3)
    b_args.update(b_kwargs)
    agvs = [AGV("A", a_pos, WHITE, **a_args), AGV("B", b_pos, WHITE, **b_args)]
    return Simulation(Grid(layout), agvs, strategy, weights)


OPEN_ROW = "P" + "." * 28 + "D"      # one long corridor, pickup at one end


# ---------------------------------------------------------------- A*
def test_astar_straight_line():
    assert astar(Grid("....\n...."), (0, 0), (3, 0)) == [(0, 0), (1, 0), (2, 0), (3, 0)]


def test_astar_goes_around_wall():
    grid = Grid(".#.\n.#.\n...")
    path = astar(grid, (0, 0), (2, 0))
    assert len(path) - 1 == 6 and all(grid.is_free(c) for c in path)


def test_astar_no_route_and_same_cell():
    assert astar(Grid(".#.\n.#.\n.#."), (0, 0), (2, 0)) is None
    assert astar(Grid("..."), (1, 0), (1, 0)) == [(1, 0)]


def test_default_layout_is_connected():
    grid = Grid.default()
    cells = list(grid.pickups.values()) + list(grid.deliveries.values())
    assert cells and all(astar(grid, a, b) for a in cells for b in cells)


def test_unknown_symbol_is_rejected():
    assert raises(ValueError, Grid, "..X..")
    assert raises(ValueError, Grid, "..C..")


# ----------------------------------------------------------- Hungarian
def total(cost, pairs):
    return sum(cost[r][c] for r, c in pairs)


def brute_force_best(cost):
    from itertools import permutations
    n, m = len(cost), len(cost[0])
    if n <= m:
        return min(sum(cost[r][c] for r, c in enumerate(cols)) for cols in permutations(range(m), n))
    return min(sum(cost[r][c] for c, r in enumerate(rows)) for rows in permutations(range(n), m))


def test_hungarian_classic_example():
    cost = [[4, 1, 3], [2, 0, 5], [3, 2, 2]]
    assert total(cost, hungarian(cost)) == 5


def test_hungarian_matches_brute_force_any_shape():
    rng = random.Random(42)
    for _ in range(200):
        n, m = rng.randint(1, 5), rng.randint(1, 5)
        cost = [[rng.randint(0, 30) for _ in range(m)] for _ in range(n)]
        pairs = hungarian(cost)
        assert len(pairs) == min(n, m)
        assert len({r for r, _ in pairs}) == len(pairs) and len({c for _, c in pairs}) == len(pairs)
        assert total(cost, pairs) == brute_force_best(cost)


def test_hungarian_empty():
    assert hungarian([]) == []


# ----------------------------------------- removed features stay removed
def test_no_priority_battery_or_charging_left():
    banned = ("priorit", "charg", "batter")
    paths = [os.path.join(ROOT, p) for p in ("dashboard.py", "compare.py", "main.py", "README.md")]
    for folder in ("warehouse", "data"):
        base = os.path.join(ROOT, folder)
        paths += [os.path.join(base, f) for f in os.listdir(base) if f.endswith((".py", ".csv"))]
    for path in paths:
        text = open(path, encoding="utf-8").read().lower()
        for word in banned:
            assert word not in text, f"'{word}' found in {os.path.basename(path)}"


def test_models_have_no_removed_fields():
    sim = default_simulation()
    order = sim.add_order("P1", "D1", 10)
    assert not hasattr(order, "priority")
    assert not any(hasattr(sim.agvs[0], n) for n in ("battery", "bat", "charger"))
    assert not hasattr(sim.grid, "chargers")


# ------------------------------------------------- speeds and estimates
def test_agvs_have_different_speeds_and_limits():
    agvs = default_simulation().agvs
    assert len({a.speed for a in agvs}) == 4 and len({a.max_load for a in agvs}) == 4
    assert all(a.speed <= 3.0 for a in agvs)         # slow enough to watch


def test_faster_robot_covers_more_ground_in_same_time():
    sim = two_robot_sim("P" + "." * 28 + "D\n" + "." * 30, (0, 0), (0, 1), strategy="FCFS", speed=4.0)
    sim.agvs[0].path = [(i, 0) for i in range(1, 30)]       # two separate lanes
    sim.agvs[1].path = [(i, 1) for i in range(1, 30)]
    for _ in range(50):
        sim._drive(sim.agvs[0], 0.1)
        sim._drive(sim.agvs[1], 0.1)
    assert abs(sim.agvs[0].distance - 10.0) < 1e-6 and abs(sim.agvs[1].distance - 20.0) < 1e-6


def test_estimated_time_matches_real_time():
    sim = default_simulation()
    agv = sim.agvs[0]
    order = sim.add_order("P1", "D1", 30)
    sim.agvs[1].max_load = sim.agvs[2].max_load = sim.agvs[3].max_load = 0   # only AGV-01 can take it
    expected = sim.estimate(agv, order)["T"]
    run(sim)
    assert order.status == "Completed"
    assert abs((order.completed_at - order.created_at) - expected) < 0.5


def test_energy_follows_distance_and_rate():
    sim = default_simulation()
    random_orders(sim, 8, random.Random(5))
    run(sim)
    for a in sim.agvs:
        low, high = a.distance * a.energy_rate, a.distance * a.energy_rate * (1 + config.LOAD_ENERGY_FACTOR)
        assert low - 1e-6 <= a.energy_used <= high + 1e-6
        assert a.empty_distance <= a.distance + 1e-9


def test_farther_but_faster_robot_is_chosen():
    # A is 6 cells from the pickup, B is 18 cells away but twice as fast.
    layout = "..........P.......................D\n"
    sim = two_robot_sim(layout, (4, 0), (22, 0), speed=4.0)
    sim.weights = {"alpha": 1.0, "beta": 0.0, "gamma": 0.0}
    order = sim.add_order("P1", "D1", 20)
    sim.step()
    assert order.agv == "B"
    near = Simulation(Grid(layout), [AGV("A", (4, 0), WHITE, 2.0, 100, 0.5, 0.3),
                                      AGV("B", (22, 0), WHITE, 2.0, 100, 0.5, 0.3)], "Nearest")
    other = near.add_order("P1", "D1", 20)
    near.step()
    assert other.agv == "A"                          # Nearest ignores speed


# ----------------------------------------------- weights change decisions
def weighted_choice(weights):
    layout = "." * 12 + "P" + "." * 8 + "D\n"
    sim = Simulation(Grid(layout), [
        AGV("Fast", (12, 0), WHITE, speed=3.0, max_load=100, energy_rate=0.9, time_cost=0.3),
        AGV("Thrifty", (12, 0), WHITE, speed=1.5, max_load=100, energy_rate=0.3, time_cost=0.3),
    ], "Hungarian", weights)
    order = sim.add_order("P1", "D1", 30)
    sim.step()
    return order.agv


def test_weights_change_the_assignment():
    assert weighted_choice(config.PRESETS["Time"]) == "Fast"
    assert weighted_choice(config.PRESETS["Energy"]) == "Thrifty"


def test_changing_weights_replans_waiting_orders():
    layout = "." * 12 + "P" + "." * 8 + "D\n"
    sim = Simulation(Grid(layout), [
        AGV("Fast", (12, 0), WHITE, 3.0, 100, 0.9, 0.3), AGV("Thrifty", (12, 0), WHITE, 1.5, 100, 0.3, 0.3),
    ], "Hungarian", {"alpha": 1, "beta": 0, "gamma": 0})
    sim.agvs[0].order = sim.add_order("P1", "D1", 10)     # Fast is busy...
    sim.agvs[0].status, sim.agvs[0].wait_left, sim.agvs[0].after_wait = "Waiting", 5.0, "delivery"
    sim.agvs[0].order.status = "In Progress"
    later = sim.add_order("P1", "D1", 10)
    sim.step()
    first = later.agv
    sim.set_weights(alpha=0.0, beta=1.0, gamma=0.0)
    sim.step()
    assert later.agv == "Thrifty" and first is not None


def test_workload_penalty_spreads_orders():
    layout = "." * 6 + "P" + "." * 4 + "D\n"
    def build(gamma):
        sim = Simulation(Grid(layout), [AGV("A", (6, 0), WHITE, 2.0, 100, 0.5, 0.3),
                                         AGV("B", (11, 0), WHITE, 2.0, 100, 0.5, 0.3)],
                         "Hungarian", {"alpha": 0.3, "beta": 0.0, "gamma": gamma})
        for _ in range(2):
            sim.add_order("P1", "D1", 10)
        sim.step()
        return sorted(len(a.queue) + (1 if a.order else 0) for a in sim.agvs)
    assert build(gamma=1.0) == [1, 1]


# ------------------------------------------------ multiple simultaneous orders
def test_more_orders_than_robots_all_complete():
    sim = default_simulation()
    random_orders(sim, 12, random.Random(1))
    sim.step()
    assert sum(1 for o in sim.orders if o.status == "Pending") > 0 or len(sim.agvs) * config.MAX_ASSIGNED >= 12
    assert all(a.held() <= config.MAX_ASSIGNED for a in sim.agvs)
    run(sim)
    assert all(o.status in ("Completed", "Failed") for o in sim.orders)
    assert sum(o.status == "Completed" for o in sim.orders) >= 10


def test_fewer_orders_than_robots():
    sim = default_simulation()
    orders = [sim.add_order("P1", "D1", 20), sim.add_order("P2", "D2", 20)]
    sim.step()
    assert len({o.agv for o in orders}) == 2 and all(o.agv for o in orders)
    run(sim)
    assert all(o.status == "Completed" for o in orders)


def test_every_robot_gets_work_when_many_orders_arrive():
    sim = default_simulation()
    random_orders(sim, 16, random.Random(2))
    run(sim)
    assert all(a.orders_done > 0 for a in sim.agvs)


def test_heavy_order_goes_to_robot_that_can_carry_it():
    sim = default_simulation()
    order = sim.add_order("P2", "D1", 120)               # only AGV-03 carries 150 kg
    run(sim)
    assert order.status == "Completed" and order.agv == "AGV-03"


def test_impossible_order_fails_cleanly():
    sim = default_simulation()
    order = sim.add_order("P1", "D1", 500)
    sim.step()
    assert order.status == "Failed"
    assert sim.is_finished()


def test_invalid_orders_are_rejected():
    sim = default_simulation()
    for args in [("P9", "D1", 10), ("P1", "D9", 10), ("P1", "D1", 0), ("P1", "D1", -5)]:
        assert raises(ValueError, sim.add_order, *args), args


# ------------------------------------------------- dynamic reassignment
def test_started_orders_are_never_reassigned():
    sim = default_simulation()
    rng = random.Random(9)
    random_orders(sim, 10, rng)
    owner = {}
    for tick in range(6000):
        if tick % 200 == 0 and tick < 2000:
            random_orders(sim, 2, rng)                    # new orders keep arriving
        sim.step()
        for a in sim.agvs:
            if a.order:
                assert owner.setdefault(a.order.id, a.name) == a.name
        if sim.is_finished():
            break
    assert sim.is_finished()


def test_new_order_can_change_the_plan_for_waiting_orders():
    layout = "." * 6 + "P" + "." * 4 + "D\n"
    sim = Simulation(Grid(layout), [AGV("A", (6, 0), WHITE, 2.0, 100, 0.5, 0.3)], "Hungarian")
    sim.agvs[0].status, sim.agvs[0].order, sim.agvs[0].wait_left, sim.agvs[0].after_wait = \
        "Waiting", sim.add_order("P1", "D1", 5), 4.0, "delivery"
    sim.agvs[0].order.status = "In Progress"
    queued = sim.add_order("P1", "D1", 5)
    sim.step()
    assert queued.status == "Assigned"
    sim.agvs.append(AGV("B", (6, 0), WHITE, 2.0, 100, 0.5, 0.3))   # a new robot becomes available
    sim.dirty = True
    sim.step()
    assert queued.agv == "B"


# ----------------------------------------------------------- metrics
def test_metrics_are_consistent():
    sim = default_simulation()
    random_orders(sim, 15, random.Random(3), spread=60)
    run(sim)
    m = sim.metrics()
    assert m["completed"] + m["failed"] == m["total"] == 15
    assert 0 < m["utilization"] <= 100
    assert m["empty_distance"] <= m["distance"] and m["energy"] > 0 and m["cost"] > 0
    assert m["avg_time"] > 0 and m["balance"] >= 0
    assert abs(m["cost"] - (m["energy"] * config.ENERGY_PRICE + sum(a.busy_time * a.time_cost for a in sim.agvs))) < 1e-6


def test_hungarian_beats_fcfs_and_energy_weights_save_energy():
    runs = [compare.run_all(type("A", (), {"orders": 30, "seed": seed, "spread": 120, "csv": None})())
            for seed in (1, 2, 3, 4, 5)]
    assert all(set(r) == {c[0] for c in compare.CONFIGS} for r in runs)
    assert all(res["completed"] == 30 for r in runs for res in r.values())

    def mean(name, key):
        return sum(r[name][key] for r in runs) / len(runs)

    assert mean("Hungarian-Time", "avg_time") < mean("FCFS", "avg_time")
    assert mean("Hungarian-Energy", "energy") < mean("Hungarian-Time", "energy")


def test_runs_are_repeatable():
    a = default_simulation(); b = default_simulation()
    random_orders(a, 10, random.Random(4)); random_orders(b, 10, random.Random(4))
    run(a); run(b)
    assert a.metrics() == b.metrics()


# ------------------------------------------------------ CSV and random orders
def write_csv(rows, header="pickup,delivery,weight,arrival"):
    f = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False, newline="")
    f.write(header + "\n" + "\n".join(rows) + "\n")
    f.close()
    return f.name


def test_csv_import_good_and_bad_rows():
    sim = default_simulation()
    path = write_csv(["P1,D1,30,0", "P2,D2,45,20", "P9,D1,10,0", "P1,D1,abc,0", "P1,D1,-3,0"])
    added, errors = load_orders_csv(path, sim)
    assert len(added) == 2 and len(errors) == 3
    assert len(sim.orders) == 1 and len(sim.incoming) == 1        # the second one arrives later
    os.remove(path)


def test_csv_without_arrival_column_and_missing_columns():
    sim = default_simulation()
    path = write_csv(["P1,D1,30"], header="pickup,delivery,weight")
    assert len(load_orders_csv(path, sim)[0]) == 1
    bad = write_csv(["P1,D1"], header="pickup,delivery")
    assert load_orders_csv(bad, sim)[0] == [] and load_orders_csv(bad, sim)[1]
    os.remove(path); os.remove(bad)


def test_sample_csv_loads_and_has_no_extra_columns():
    path = os.path.join(ROOT, "data", "sample_orders.csv")
    assert next(csv.reader(open(path))) == ["pickup", "delivery", "weight", "arrival"]
    added, errors = load_orders_csv(path, default_simulation())
    assert len(added) == 9 and not errors


def test_csv_export_roundtrip():
    sim = default_simulation()
    random_orders(sim, 5, random.Random(1))
    run(sim)
    path = os.path.join(tempfile.mkdtemp(), "out.csv")
    assert export_orders_csv(path, sim) == 5
    rows = list(csv.DictReader(open(path)))
    assert len(rows) == 5 and set(rows[0]) == {"id", "pickup", "delivery", "weight", "agv", "status", "created_s", "completed_s"}
    assert all(r["status"] == "Completed" for r in rows)


def test_bulk_random_orders_are_valid_and_pending():
    sim = default_simulation()
    orders = random_orders(sim, 25, random.Random(8))
    assert len(orders) == 25 and all(o.status == "Pending" for o in orders)
    assert all(o.pickup in sim.grid.pickups and o.delivery in sim.grid.deliveries for o in orders)
    assert len({o.weight for o in orders}) > 3 and all(10 <= o.weight <= 120 for o in orders)


# ------------------------------------- collision avoidance and deadlock handling
import itertools
import math


def busy_agv(sim, agv, path, order_pickup="P1", order_delivery="D1"):
    """Put an AGV in the middle of a delivery, driving along `path`."""
    order = sim.add_order(order_pickup, order_delivery, 5)
    order.status, order.agv = "In Progress", agv.name
    agv.order, agv.load, agv.status = order, 5, "Delivering"
    agv.path, agv.progress = list(path), 0.0
    return order


def parked_agv(sim, agv, seconds=1000.0):
    """An AGV that stays where it is for a long time (as if loading)."""
    order = sim.add_order("P1", "D1", 5)
    order.status, order.agv = "In Progress", agv.name
    agv.order, agv.load = order, 5
    agv.status, agv.wait_left, agv.after_wait = "Waiting", seconds, "delivery"


def check_safety(sim, steps, dt=0.1):
    """Step the simulation and check the three safety rules after every step."""
    closest = 9.0
    for _ in range(steps):
        before = {a.name: a.pos for a in sim.agvs}
        sim.step(dt)
        assert len({a.pos for a in sim.agvs}) == len(sim.agvs), "two AGVs in one cell"
        reserved = [a.reserved for a in sim.agvs if a.reserved]
        assert len(set(reserved)) == len(reserved), "a cell reserved twice"
        for a, b in itertools.combinations(sim.agvs, 2):
            assert not (a.pos != before[a.name] and a.pos == before[b.name] and b.pos == before[a.name]), "swap"
            closest = min(closest, math.dist(a.xy(), b.xy()))
        if sim.is_finished():
            break
    return closest


def test_astar_avoids_blocked_cells_but_not_the_goal():
    grid = Grid("...\n...")
    path = astar(grid, (0, 0), (2, 0), blocked={(1, 0)})
    assert (1, 0) not in path and path[-1] == (2, 0)
    assert astar(grid, (0, 0), (2, 0), blocked={(2, 0)}) is not None        # an occupied goal is still reachable


def test_agv_waits_when_next_cell_is_occupied():
    sim = two_robot_sim("P" + "." * 5 + "D", (0, 0), (1, 0))
    a, b = sim.agvs
    busy_agv(sim, a, [(1, 0), (2, 0)])
    parked_agv(sim, b, 100.0)                                               # B stays put for a long time
    for _ in range(20):                                                     # 2 simulated seconds
        sim.step(0.1)
    assert a.pos == (0, 0) and a.progress == 0.0 and a.reserved is None
    assert a.blocked and a.blocker is b
    assert abs(a.blocked_time - 2.0) < 0.2 and abs(a.blocked_total - 2.0) < 0.2


def test_two_agvs_cannot_enter_the_same_cell():
    sim = two_robot_sim("P" + "." * 4 + "D", (0, 0), (2, 0))
    a, b = sim.agvs
    busy_agv(sim, a, [(1, 0), (2, 0)])
    busy_agv(sim, b, [(1, 0), (0, 0)])
    sim.step(0.1)
    assert [x.reserved for x in sim.agvs].count((1, 0)) == 1            # only one got the cell


def test_head_on_agvs_never_swap_and_wait_instead():
    sim = two_robot_sim("P" + "." * 4 + "D", (1, 0), (2, 0))
    a, b = sim.agvs
    busy_agv(sim, a, [(2, 0), (3, 0)])
    busy_agv(sim, b, [(1, 0), (0, 0)])
    closest = check_safety(sim, 30)                                      # 3 seconds, well below the timeout
    assert a.pos == (1, 0) and b.pos == (2, 0)
    assert a.blocked and b.blocked and closest >= 1.0 - 1e-9


def test_blocked_agv_finds_another_route_after_timeout():
    sim = two_robot_sim("P.....D\n.......\n.......", (0, 1), (3, 1))
    a, b = sim.agvs
    delivery = busy_agv(sim, a, [(1, 1), (2, 1), (3, 1), (4, 1), (5, 1)])
    parked_agv(sim, b)                                                    # B blocks the middle of the row
    check_safety(sim, int((config.DEADLOCK_TIMEOUT + 3) * 10))
    assert a.reroutes == 1 and (3, 1) not in a.path
    assert any("another route" in text for _, _, text in sim.events)
    check_safety(sim, 300)
    assert delivery.status == "Completed" and b.pos == (3, 1)


def test_idle_agv_moves_aside():
    sim = two_robot_sim("..#.....\nP.......\n..#...D.", (0, 1), (3, 1))
    a, b = sim.agvs
    busy_agv(sim, a, [(1, 1), (2, 1), (3, 1), (4, 1), (5, 1)])
    sim.agvs[1].status = "Idle"
    check_safety(sim, 100)
    assert any("moves aside" in text for _, _, text in sim.events)
    assert a.pos[0] >= 4                                                  # A got through


def test_head_on_standoff_in_a_corridor_is_resolved():
    layout = "###P###\nD.....D"                     # a corridor with one pocket (the pickup cell)
    sim = two_robot_sim(layout, (1, 1), (5, 1))
    a, b = sim.agvs
    first = busy_agv(sim, a, [(2, 1), (3, 1), (4, 1), (5, 1), (6, 1)], "P1", "D2")
    second = busy_agv(sim, b, [(4, 1), (3, 1), (2, 1), (1, 1), (0, 1)], "P1", "D1")
    check_safety(sim, 1500)
    assert first.status == "Completed" and second.status == "Completed"
    assert any("backs off" in text for _, _, text in sim.events)


def test_boxed_in_idle_agvs_clear_the_way():
    sim = default_simulation()
    for agv, cell in zip(sim.agvs, [(2, 4), (3, 3), (2, 3), (1, 3)]):    # three idle AGVs surround D2
        agv.pos = agv.prev_pos = cell
    order = sim.add_order("P1", "D2", 20)
    check_safety(sim, 3000)
    assert order.status == "Completed"


def test_no_collisions_or_swaps_in_a_busy_warehouse():
    for strategy, seed in [("FCFS", 5), ("Nearest", 7), ("Hungarian", 1)]:   # seeds 5 and 7 once deadlocked
        sim = default_simulation(strategy)
        random_orders(sim, 30, random.Random(seed), spread=100)
        closest = check_safety(sim, 20000)
        assert sim.is_finished(), (strategy, seed)
        assert closest >= 1.0 - 1e-9
        m = sim.metrics()
        assert m["completed"] == 30 and m["blocked"] > 0 and m["reroutes"] >= 0


def test_many_orders_never_deadlock():
    for strategy in config.STRATEGIES:
        for seed in range(1, 5):
            sim = default_simulation(strategy)
            random_orders(sim, 40, random.Random(seed))
            while not sim.is_finished() and sim.time < 3000:
                sim.step()
            assert sim.is_finished(), (strategy, seed)


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_")]
    for name, fn in tests:
        fn()
        print("ok  ", name)
    print(f"\n{len(tests)} tests passed")
