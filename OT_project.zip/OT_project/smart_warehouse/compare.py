"""Run every strategy on the exact same warehouse, robots and orders, and compare the results.

    python compare.py                       # 30 random orders, seed 1
    python compare.py --orders 60 --seed 7
    python compare.py --csv data/sample_orders.csv
    python compare.py --out results.csv --chart

Rows: FCFS, Nearest, and the Hungarian strategy with three weight settings
(time-focused, energy-focused, balanced). All numbers come from real simulation runs.
"""
import argparse
import csv
import random

from warehouse import config
from warehouse.orders_io import load_orders_csv, random_orders
from warehouse.simulation import default_simulation

MAX_TIME = 20000   # seconds; safety stop

CONFIGS = [
    ("FCFS", "FCFS", None),
    ("Nearest", "Nearest", None),
    ("Hungarian-Time", "Hungarian", "Time"),
    ("Hungarian-Energy", "Hungarian", "Energy"),
    ("Hungarian-Balanced", "Hungarian", "Balanced"),
]

COLUMNS = [
    ("completed", "Done", "{:.0f}"),
    ("makespan", "Finish (s)", "{:.0f}"),
    ("avg_time", "Avg time (s)", "{:.1f}"),
    ("distance", "Distance", "{:.0f}"),
    ("empty_distance", "Empty dist.", "{:.0f}"),
    ("energy", "Energy", "{:.1f}"),
    ("cost", "Cost (Rs)", "{:.1f}"),
    ("utilization", "Utiliz. %", "{:.1f}"),
    ("balance", "Balance (s)", "{:.2f}"),
    ("blocked", "Blocked (s)", "{:.0f}"),
]


def run_config(strategy, preset, args):
    """Run one configuration to completion and return its metrics."""
    weights = config.PRESETS[preset] if preset else None
    sim = default_simulation(strategy, weights)
    if args.csv:
        load_orders_csv(args.csv, sim)
    else:
        random_orders(sim, args.orders, random.Random(args.seed), spread=args.spread)
    while not sim.is_finished() and sim.time < MAX_TIME:
        sim.step()
    result = sim.metrics()
    result["makespan"] = sim.time
    return result


def run_all(args):
    return {label: run_config(strategy, preset, args) for label, strategy, preset in CONFIGS}


def print_table(results):
    header = f"{'Configuration':<20}" + "".join(f"{label:>14}" for _, label, _ in COLUMNS)
    print(header)
    print("-" * len(header))
    for name, res in results.items():
        print(f"{name:<20}" + "".join(f"{fmt.format(res[key]):>14}" for key, _, fmt in COLUMNS))


def save_csv(results, path):
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["configuration"] + [key for key, _, _ in COLUMNS])
        for name, res in results.items():
            writer.writerow([name] + [round(res[key], 3) for key, _, _ in COLUMNS])
    print(f"results saved to {path}")


def save_chart(results, path="comparison.png"):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("(matplotlib not installed - skipping chart)")
        return
    picks = [("avg_time", "Avg completion time (s)"), ("distance", "Total distance (cells)"),
             ("energy", "Energy (units)"), ("cost", "Operating cost (Rs)")]
    fig, axes = plt.subplots(1, len(picks), figsize=(16, 3.8))
    colours = ["#64748b", "#94a3b8", "#3b82f6", "#f97316", "#22c55e"]
    for ax, (key, title) in zip(axes, picks):
        ax.bar(range(len(results)), [r[key] for r in results.values()], color=colours)
        ax.set_xticks(range(len(results)))
        ax.set_xticklabels([n.replace("Hungarian-", "H-") for n in results], fontsize=8, rotation=20)
        ax.set_title(title, fontsize=10)
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    print(f"chart saved to {path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--orders", type=int, default=30)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--spread", type=float, default=120, help="orders arrive over this many seconds")
    parser.add_argument("--csv", help="use orders from a CSV instead of random ones")
    parser.add_argument("--out", help="also save the table as a CSV file")
    parser.add_argument("--chart", action="store_true", help="also save comparison.png")
    args = parser.parse_args()

    results = run_all(args)
    print_table(results)
    if args.out:
        save_csv(results, args.out)
    if args.chart:
        save_chart(results)


if __name__ == "__main__":
    main()
