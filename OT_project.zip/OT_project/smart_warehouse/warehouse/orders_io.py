"""Getting orders in and out: CSV files and random generation."""
import csv
import random

COLUMNS = ["pickup", "delivery", "weight", "arrival"]


def load_orders_csv(path, sim):
    """Read orders from a CSV and add them to the simulation. Returns (added, errors).

    Columns: pickup, delivery, weight, arrival   (arrival is optional: seconds after import)
    Bad rows are skipped and reported; good rows are still imported.
    """
    added, errors = [], []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        missing = {"pickup", "delivery", "weight"} - set(reader.fieldnames or [])
        if missing:
            return [], [f"missing column(s): {', '.join(sorted(missing))}"]
        for line_no, row in enumerate(reader, start=2):
            try:
                arrival = (row.get("arrival") or "").strip()
                added.append(sim.add_order(
                    (row["pickup"] or "").strip(),
                    (row["delivery"] or "").strip(),
                    float(row["weight"]),
                    sim.time + float(arrival) if arrival else None,
                ))
            except (ValueError, TypeError) as err:
                errors.append(f"line {line_no}: {err}")
    return added, errors


def random_orders(sim, count, rng=None, spread=0.0, weights=range(10, 125, 5)):
    """Add `count` random orders with valid locations and random weights (kg).

    With spread > 0 the orders arrive at random times within the next `spread` seconds.
    """
    rng = rng or random.Random()
    pickups = list(sim.grid.pickups)
    deliveries = list(sim.grid.deliveries)
    weights = list(weights)
    return [sim.add_order(rng.choice(pickups), rng.choice(deliveries), rng.choice(weights),
                          sim.time + rng.uniform(0, spread) if spread else None)
            for _ in range(count)]


def export_orders_csv(path, sim):
    """Write every order and its outcome to a CSV file."""
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["id", "pickup", "delivery", "weight", "agv", "status", "created_s", "completed_s"])
        for o in sim.orders:
            writer.writerow([o.id, o.pickup, o.delivery, f"{o.weight:g}", o.agv or "", o.status,
                             f"{o.created_at:.1f}",
                             "" if o.completed_at is None else f"{o.completed_at:.1f}"])
    return len(sim.orders)
