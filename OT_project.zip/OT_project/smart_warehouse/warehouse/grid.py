"""The warehouse floor: a 2D grid made from a small text picture.

    #  shelf / obstacle      .  free floor
    P  pickup location       D  delivery station

Pickups and deliveries are named in reading order (P1, P2 ... D1, D2 ...).
Make your own warehouse by writing a text file like this and using Grid.from_file().
"""

DEFAULT_LAYOUT = """
....................
###..#.###..D..#....
###.P..###.....#....
..D............#....
##.....###...##..##.
##.....###...##..##.
....................
...##.##.###.##.##..
#..##.##.###.##.##..
#.........P.........
........###.....##..
#.......###..##.##.D
##.............P....
##....##..##.......#
##....##..##........
#..#...#..#...#...##
"""


class Grid:
    def __init__(self, layout):
        lines = [line for line in layout.strip().splitlines() if line.strip()]
        if not lines:
            raise ValueError("layout is empty")
        self.rows = len(lines)
        self.cols = len(lines[0])
        self.obstacles = set()
        self.pickups = {}      # name -> (col, row)
        self.deliveries = {}

        for r, line in enumerate(lines):
            if len(line) != self.cols:
                raise ValueError(f"row {r} has {len(line)} cells, expected {self.cols}")
            for c, ch in enumerate(line):
                if ch == "#":
                    self.obstacles.add((c, r))
                elif ch == "P":
                    self.pickups[f"P{len(self.pickups) + 1}"] = (c, r)
                elif ch == "D":
                    self.deliveries[f"D{len(self.deliveries) + 1}"] = (c, r)
                elif ch != ".":
                    raise ValueError(f"unknown symbol '{ch}' at row {r}, col {c}")

    @classmethod
    def default(cls):
        return cls(DEFAULT_LAYOUT)

    @classmethod
    def from_file(cls, path):
        with open(path) as f:
            return cls(f.read())

    def in_bounds(self, cell):
        c, r = cell
        return 0 <= c < self.cols and 0 <= r < self.rows

    def is_free(self, cell):
        return self.in_bounds(cell) and cell not in self.obstacles

    def neighbors(self, cell):
        c, r = cell
        for step in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nxt = (c + step[0], r + step[1])
            if self.is_free(nxt):
                yield nxt
