"""Every tunable number lives here, so it is easy to find and change."""

# --- time (all in simulated seconds) -------------------------------------
SIM_DT = 0.1               # step used by headless runs (the dashboard uses smaller, frame-sized steps)
LOAD_TIME = 3.0            # seconds an AGV waits while loading or unloading a package

# --- energy and money ----------------------------------------------------
LOAD_ENERGY_FACTOR = 0.3   # a fully loaded AGV uses 30% more energy per cell
ENERGY_PRICE = 2.0         # rupees per energy unit

# --- dispatching ----------------------------------------------------------
MAX_ASSIGNED = 2           # unfinished orders one AGV may hold: the current one + one waiting

# --- collision avoidance and deadlock handling (simulated seconds) --------
BLOCK_LOG_AFTER = 1.0      # write a log line when an AGV has waited this long for a cell
DEADLOCK_TIMEOUT = 4.0     # blocked this long -> try another route (A*); twice as long -> back off
BACK_OFF_HOLD = 5.0        # an AGV that stepped aside stays there this long so the other can pass

# Cost weights used by the Hungarian strategy:  C = alpha*T + beta*E + gamma*W
#   T = completion time, E = operating cost (energy cost + time-based cost), W = remaining workload
PRESETS = {
    "Time":     {"alpha": 0.70, "beta": 0.10, "gamma": 0.20},
    "Energy":   {"alpha": 0.10, "beta": 0.70, "gamma": 0.20},
    "Balanced": {"alpha": 0.40, "beta": 0.30, "gamma": 0.30},
}

STRATEGIES = ["FCFS", "Nearest", "Hungarian"]

# Dashboard playback: how many simulated seconds pass per real second.
# This is NOT the AGV speed. AGV speed (cells/second) is a property of each robot.
PLAYBACK = [("Slow", 0.5), ("Normal", 1.0), ("Fast", 4.0)]
