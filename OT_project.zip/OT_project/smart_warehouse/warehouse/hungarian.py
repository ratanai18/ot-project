"""Hungarian algorithm (Kuhn-Munkres) written from scratch.

Finds the assignment with the smallest total cost.
Works for any matrix shape: if there are more rows than columns we simply
flip the matrix, solve it, and flip the answer back.
"""


def hungarian(cost):
    """cost[i][j] = price of giving row i to column j.

    Returns a list of (row, col) pairs. Each row and column is used at most once,
    and min(rows, cols) pairs are returned.
    """
    if not cost or not cost[0]:
        return []

    flipped = len(cost) > len(cost[0])
    if flipped:
        cost = [list(col) for col in zip(*cost)]

    n = len(cost)        # rows (n <= m now)
    m = len(cost[0])     # columns
    INF = float("inf")

    # u / v are the "potentials". p[j] = which row currently owns column j.
    # Everything is 1-indexed so index 0 can act as a dummy start.
    u = [0.0] * (n + 1)
    v = [0.0] * (m + 1)
    p = [0] * (m + 1)
    way = [0] * (m + 1)

    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        min_v = [INF] * (m + 1)
        used = [False] * (m + 1)

        # grow an alternating tree until we find a free column
        while True:
            used[j0] = True
            i0 = p[j0]
            delta = INF
            j1 = 0
            for j in range(1, m + 1):
                if not used[j]:
                    cur = cost[i0 - 1][j - 1] - u[i0] - v[j]
                    if cur < min_v[j]:
                        min_v[j] = cur
                        way[j] = j0
                    if min_v[j] < delta:
                        delta = min_v[j]
                        j1 = j
            for j in range(m + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    min_v[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break

        # walk back along the tree and flip the matching
        while j0:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1

    pairs = []
    for j in range(1, m + 1):
        if p[j]:
            row, col = p[j] - 1, j - 1
            pairs.append((col, row) if flipped else (row, col))
    return sorted(pairs)
