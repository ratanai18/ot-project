"""The warehouse simulation. step(dt) moves warehouse time forward by dt seconds."""
import statistics

from . import config, strategies
from .astar import astar
from .grid import Grid
from .models import AGV, Order

BLUE, GREEN, ORANGE, PINK = (59, 130, 246), (34, 197, 94), (249, 115, 22), (236, 72, 153)
BUSY = ("To Pickup", "Delivering", "Waiting")


class Simulation:
    def __init__(self, grid, agvs, strategy="Hungarian", weights=None):
        self.grid = grid
        self.agvs = agvs
        self.strategy = strategy
        self.weights = dict(weights or config.PRESETS["Balanced"])
        self.time = 0.0           # simulated seconds
        self.orders = []          # orders that exist right now
        self.incoming = []        # orders that will arrive later
        self.next_id = 1001
        self.events = []          # (time, colour name, text)
        self.dirty = True         # something changed, so assignments should be recalculated
        self._paths = {}          # cache: (start, goal) -> path
        self._balance_clock = 0.0
        self._balance_sum = 0.0
        self._balance_samples = 0

    # ------------------------------------------------------------ helpers
    def clock(self):
        secs = int(self.time)
        return f"{secs // 3600:02d}:{secs % 3600 // 60:02d}:{secs % 60:02d}"

    def log(self, text, colour="blue"):
        self.events.append((self.time, colour, text))
        del self.events[:-200]

    def path(self, start, goal):
        """A* result, remembered because the warehouse layout never changes."""
        key = (start, goal)
        if key not in self._paths:
            self._paths[key] = astar(self.grid, start, goal)
        return self._paths[key]

    def distance(self, start, goal):
        p = self.path(start, goal)
        return None if p is None else len(p) - 1

    def set_weights(self, **changes):
        """Change alpha / beta / gamma. Waiting orders are re-planned right away."""
        self.weights.update(changes)
        self.dirty = True

    def set_strategy(self, name):
        if name != self.strategy:
            self.strategy = name
            self.dirty = True
            self.log(f"Strategy changed to {name}", "purple")

    # ------------------------------------------------------------- orders
    def add_order(self, pickup, delivery, weight, arrival=None):
        """Create an order. `arrival` is the time (seconds) it shows up; default is now."""
        if pickup not in self.grid.pickups:
            raise ValueError(f"unknown pickup location '{pickup}'")
        if delivery not in self.grid.deliveries:
            raise ValueError(f"unknown delivery location '{delivery}'")
        if not weight > 0:
            raise ValueError("weight must be positive")

        created = self.time if arrival is None else max(arrival, self.time)
        order = Order(self.next_id, pickup, delivery, weight, created)
        self.next_id += 1
        if created > self.time:
            self.incoming.append(order)
        else:
            self._release(order)
        return order

    def _release(self, order):
        self.orders.append(order)
        self.dirty = True
        self.log(f"New order #{order.id} received ({order.pickup} \u2192 {order.delivery}, {order.weight:g} kg)", "purple")

    # --------------------------------------------------------- estimates
    def projection(self, agv):
        """Where will this AGV be, and in how many seconds, after its current job and queue?

        Returns (cell, seconds). The seconds value is the AGV's remaining workload W.
        """
        pos, seconds = agv.pos, 0.0
        order = agv.order
        if order:
            pickup = self.grid.pickups[order.pickup]
            delivery = self.grid.deliveries[order.delivery]
            leg = self.distance(pickup, delivery) / agv.speed
            if agv.status == "To Pickup":
                seconds = agv.remaining_cells() / agv.speed + leg + 2 * config.LOAD_TIME
            elif agv.status == "Delivering":
                seconds = agv.remaining_cells() / agv.speed + config.LOAD_TIME
            else:   # Waiting
                seconds = agv.wait_left
                if agv.after_wait == "pickup":
                    seconds += leg + config.LOAD_TIME
            pos = delivery
        for queued in agv.queue:
            pickup = self.grid.pickups[queued.pickup]
            delivery = self.grid.deliveries[queued.delivery]
            seconds += (self.distance(pos, pickup) + self.distance(pickup, delivery)) / agv.speed \
                + 2 * config.LOAD_TIME
            pos = delivery
        return pos, seconds

    def estimate(self, agv, order):
        """What would it cost if `agv` took `order` after finishing what it already holds?

        Returns None if it is impossible (too heavy, or no route), otherwise a dict:
            d1, d2   cells driven empty to the pickup / loaded to the delivery
            T        task completion time in seconds, at this AGV's own speed
            energy   energy units used (empty leg + loaded leg)
            E        operating cost in rupees = energy cost + time-based cost
            W        seconds until this AGV is free to start the task (its workload)
        """
        if order.weight > agv.max_load:
            return None
        pickup = self.grid.pickups[order.pickup]
        delivery = self.grid.deliveries[order.delivery]
        free_cell, free_in = self.projection(agv)
        d1 = self.distance(free_cell, pickup)
        d2 = self.distance(pickup, delivery)
        if d1 is None or d2 is None:
            return None

        seconds = (d1 + d2) / agv.speed + 2 * config.LOAD_TIME
        energy = agv.energy_per_cell(0) * d1 + agv.energy_per_cell(order.weight) * d2
        energy_cost = energy * config.ENERGY_PRICE
        time_cost = seconds * agv.time_cost
        return {"d1": d1, "d2": d2, "T": seconds, "energy": energy,
                "E": energy_cost + time_cost, "W": free_in}

    def _possible(self, agv, order):
        """Could this AGV ever do the order (ignoring what it is busy with)?"""
        if order.weight > agv.max_load:
            return False
        pickup = self.grid.pickups[order.pickup]
        delivery = self.grid.deliveries[order.delivery]
        return self.distance(agv.pos, pickup) is not None and self.distance(pickup, delivery) is not None

    # ---------------------------------------------------------- dispatch
    def _dispatch(self):
        """Plan which AGV gets which order.

        * Orders that an AGV is already working on are never touched.
        * Orders that are only waiting in an AGV's queue are put back and planned again,
          together with the pending ones, so new orders can change the plan.
        """
        previous = {}
        for agv in self.agvs:
            for order in agv.queue:
                previous[order.id] = agv.name
                order.status, order.agv = "Pending", None
            agv.queue = []

        pending = sorted((o for o in self.orders if o.status == "Pending"),
                         key=lambda o: (o.created_at, o.id))

        for order in list(pending):          # give up on orders no AGV could ever do
            if not any(self._possible(a, order) for a in self.agvs):
                order.status = "Failed"
                pending.remove(order)
                self.log(f"Order #{order.id} failed: no AGV can carry {order.weight:g} kg", "red")

        while pending:                       # each round gives at most one order to each AGV
            eligible = [a for a in self.agvs if a.held() < config.MAX_ASSIGNED]
            if not eligible:
                break
            pairs = strategies.assign(self.strategy, self, pending, eligible)
            if not pairs:
                break
            for agv, order in pairs:
                agv.queue.append(order)
                order.status, order.agv = "Assigned", agv.name
                pending.remove(order)

        for agv in self.agvs:
            for order in agv.queue:
                before = previous.get(order.id)
                if before is None:
                    self.log(f"Order #{order.id} assigned to {agv.name}", "blue")
                elif before != agv.name:
                    self.log(f"Order #{order.id} moved from {before} to {agv.name}", "blue")
        for agv in self.agvs:
            if agv.status == "Idle" and agv.queue:
                self._start_next(agv)

    def _start_next(self, agv):
        order = agv.queue.pop(0)
        agv.order = order
        agv.status = "To Pickup"
        agv.path = list(self.path(agv.pos, self.grid.pickups[order.pickup]))[1:]
        agv.progress = 0.0
        self.log(f"{agv.name} starting order #{order.id}", "blue")

    # --------------------------------------------------------------- step
    def step(self, dt=config.SIM_DT):
        self.time += dt
        for order in [o for o in self.incoming if o.created_at <= self.time]:
            self.incoming.remove(order)
            self._release(order)
        if self.dirty:
            self.dirty = False
            self._dispatch()
        for agv in self._turn_order():
            self._update(agv, dt)
        if self.dirty:
            self.dirty = False
            self._dispatch()
        self._sample_balance(dt)

    def _update(self, agv, dt):
        if agv.status == "Idle":
            return
        if agv.status == "Yielding":            # stepping aside for another AGV
            self._drive(agv, dt)
            if not agv.path:
                agv.status = "Idle"
                self.dirty = True
            return
        agv.busy_time += dt
        if agv.status in ("To Pickup", "Delivering"):
            self._drive(agv, dt)
            if not agv.path:
                self._arrive(agv)
        elif agv.status == "Waiting":
            agv.wait_left -= dt
            if agv.wait_left <= 1e-9:
                self._finish_waiting(agv)

    def _drive(self, agv, dt):
        """Move along the path. A faster AGV simply covers more cells per second.

        Before leaving a cell centre the AGV must reserve the next cell. If another AGV is
        standing on it or has reserved it, this AGV waits. Two AGVs can therefore never enter
        the same cell, and never swap cells (each would be waiting for the other's cell).
        """
        if agv.hold > 0:                        # stepped aside on purpose: stay put for a moment
            agv.hold -= dt
            agv.blocked, agv.blocker = True, None
            agv.blocked_total += dt
            if agv.hold <= 0:
                self._clear_block(agv)
            return
        budget = agv.speed * dt
        while budget > 1e-12 and agv.path:
            if agv.progress <= 1e-9 and agv.reserved is None:
                holder = self._holder(agv, agv.path[0])
                if holder:
                    self._wait_for(agv, holder, dt)
                    return
                agv.reserved = agv.path[0]
                self._clear_block(agv)
            moved = min(budget, 1.0 - agv.progress)
            agv.distance += moved
            if agv.load == 0:
                agv.empty_distance += moved
            agv.energy_used += moved * agv.energy_per_cell(agv.load)
            agv.progress += moved
            budget -= moved
            if agv.progress >= 1.0 - 1e-9:
                agv.last_cell = agv.pos
                agv.pos = agv.path.pop(0)
                agv.progress = 0.0
                agv.reserved = None
                if agv.side_cell is not None and agv.pos == agv.side_cell:
                    agv.side_cell = None
                    agv.hold = config.BACK_OFF_HOLD
                    break

    # ------------------------------------------------- collision avoidance
    def _holder(self, agv, cell):
        """The other AGV that is standing on `cell` or has reserved it (None if it is free)."""
        for other in self.agvs:
            if other is not agv and (other.pos == cell or other.reserved == cell):
                return other
        return None

    def _turn_order(self):
        """Who moves first in a step: the longest-waiting AGV, then loaded before empty, then by ID.

        Moving one AGV at a time means two AGVs asking for the same free cell in the same step
        can never both get it, and nobody waits forever behind newer arrivals.
        """
        return sorted(self.agvs, key=lambda a: (-a.blocked_time, 0 if a.load else 1, self.agvs.index(a)))

    def _clear_block(self, agv):
        agv.blocked = False
        agv.blocker = None
        agv.blocked_time = 0.0
        agv.rerouted = agv.backed_off = agv.logged_block = False

    def _wait_for(self, agv, holder, dt):
        """The next cell is taken: wait, keep count, and escalate if the wait drags on."""
        agv.blocked = True
        agv.blocker = holder
        agv.blocked_time += dt
        agv.blocked_total += dt
        if agv.blocked_time >= config.BLOCK_LOG_AFTER and not agv.logged_block:
            agv.logged_block = True
            self.log(f"{agv.name} is waiting for {holder.name}", "orange")

        if holder.status == "Idle":                       # rule: idle AGVs make way
            self._make_way(holder, agv)
        if agv.blocked_time >= config.DEADLOCK_TIMEOUT and not agv.rerouted:
            agv.rerouted = True                           # step 1: look for another route
            self._reroute(agv)
        elif agv.blocked_time >= 2 * config.DEADLOCK_TIMEOUT and not agv.backed_off:
            self._back_off(agv)                           # step 2: break a standoff

    def _occupied_cells(self, agv):
        cells = set()
        for other in self.agvs:
            if other is not agv:
                cells.add(other.pos)
                if other.reserved:
                    cells.add(other.reserved)
        return cells

    def _make_way(self, idle, requester, depth=0):
        """Ask an idle AGV that is in the way to step onto a free neighbouring cell.

        If it is boxed in by other idle AGVs, those are asked to move first (a few levels deep).
        """
        stations = set(self.grid.pickups.values()) | set(self.grid.deliveries.values())
        options, idle_neighbours = [], []
        for cell in self.grid.neighbors(idle.pos):
            if cell == requester.pos:
                continue
            other = self._holder(idle, cell)
            if other is None:
                options.append(((cell in requester.path, cell in stations), cell))
            elif other.status == "Idle" and other is not requester:
                idle_neighbours.append(other)
        if options:
            idle.status = "Yielding"
            idle.path = [min(options)[1]]
            idle.progress = 0.0
            self.log(f"{idle.name} moves aside for {requester.name}", "orange")
        elif depth < 3:
            for other in idle_neighbours:
                self._make_way(other, idle, depth + 1)

    def _reroute(self, agv):
        """Blocked for too long: ask A* for a route that avoids the cells other AGVs occupy."""
        goal = agv.path[-1]
        route = astar(self.grid, agv.pos, goal, self._occupied_cells(agv))
        if route and route[1:] != agv.path:
            agv.path = route[1:]
            agv.reroutes += 1
            self._clear_block(agv)
            self.log(f"{agv.name} found another route", "orange")

    def _rank(self, agv):
        """Higher rank keeps its place in a standoff: carrying a package, then waiting longer."""
        return (1 if agv.load else 0, agv.blocked_time, -self.agvs.index(agv))

    def _standoff(self, agv):
        """AGVs waiting for each other in a circle (including two meeting head-on), or None."""
        chain, other = [agv], agv.blocker
        while other is not None and other.blocked and other not in chain:
            chain.append(other)
            other = other.blocker
        return chain if other is agv else None

    def _side_cell(self, agv):
        """A free cell this AGV could step to, to get out of the other AGV's way (or None)."""
        stations = set(self.grid.pickups.values()) | set(self.grid.deliveries.values())
        other_path = agv.blocker.path if agv.blocker else []
        options = [((c in other_path, c in stations), c) for c in self.grid.neighbors(agv.pos)
                   if c != agv.path[0] and not self._holder(agv, c)]
        if options:
            return min(options)[1]
        if agv.last_cell and not self._holder(agv, agv.last_cell):
            return agv.last_cell                          # nowhere to the side: back up
        return None

    def _back_off(self, agv):
        """Standoff (AGVs waiting for each other in a circle): exactly one of them steps aside.

        The designated AGV is the lowest-ranked one that has room to move. It steps aside and
        holds still for BACK_OFF_HOLD seconds, so the others can pass instead of undoing each other.
        """
        circle = self._standoff(agv)
        if not circle:
            return                                        # just waiting for someone who is moving on
        able = [a for a in circle if self._side_cell(a) is not None]
        if not able or agv is not min(able, key=self._rank):
            return
        side = self._side_cell(agv)
        goal = agv.path[-1]
        route = astar(self.grid, side, goal, self._occupied_cells(agv)) or astar(self.grid, side, goal)
        if not route:
            return
        agv.path = [side] + route[1:]
        agv.side_cell = side
        agv.backed_off = True
        self.log(f"{agv.name} backs off to clear a standoff", "orange")

    def _arrive(self, agv):
        agv.status = "Waiting"
        agv.wait_left = config.LOAD_TIME
        if agv.order.status == "Assigned":
            agv.after_wait = "pickup"
            self.log(f"{agv.name} reached pickup {agv.order.pickup}", "blue")
        else:
            agv.after_wait = "delivery"
            self.log(f"{agv.name} reached delivery {agv.order.delivery}", "blue")

    def _finish_waiting(self, agv):
        order = agv.order
        if agv.after_wait == "pickup":
            agv.load = order.weight
            order.status = "In Progress"
            agv.status = "Delivering"
            agv.path = list(self.path(agv.pos, self.grid.deliveries[order.delivery]))[1:]
            agv.progress = 0.0
            self.log(f"{agv.name} picked up order #{order.id}", "green")
        else:
            order.status = "Completed"
            order.completed_at = self.time
            agv.load = 0
            agv.order = None
            agv.orders_done += 1
            agv.status = "Idle"
            self.dirty = True
            self.log(f"Order #{order.id} delivered by {agv.name}", "green")
            self.log(f"{agv.name} is available", "pink")

    # ------------------------------------------------------------ metrics
    def workloads(self):
        """Remaining workload of every AGV in seconds (current job + queue)."""
        return [self.projection(a)[1] for a in self.agvs]

    def _sample_balance(self, dt):
        """Once per simulated second, record how uneven the remaining workloads are."""
        self._balance_clock += dt
        if self._balance_clock < 1.0:
            return
        self._balance_clock -= 1.0
        work = self.workloads()
        if max(work) > 0:
            self._balance_sum += statistics.pstdev(work)
            self._balance_samples += 1

    def is_finished(self):
        """True when nothing is left to do (used by the headless comparison)."""
        open_orders = any(o.status in ("Pending", "Assigned", "In Progress") for o in self.orders)
        busy = any(a.status != "Idle" or a.queue for a in self.agvs)
        return not self.incoming and not open_orders and not busy

    def metrics(self):
        done = [o for o in self.orders if o.status == "Completed"]
        elapsed = max(self.time, 1e-9)
        energy = sum(a.energy_used for a in self.agvs)
        return {
            "total": len(self.orders),
            "completed": len(done),
            "pending": sum(1 for o in self.orders if o.status in ("Pending", "Assigned")),
            "failed": sum(1 for o in self.orders if o.status == "Failed"),
            "avg_time": statistics.mean(o.completed_at - o.created_at for o in done) if done else 0.0,
            "distance": sum(a.distance for a in self.agvs),
            "empty_distance": sum(a.empty_distance for a in self.agvs),
            "energy": energy,
            "cost": sum(a.operating_cost for a in self.agvs),
            "blocked": sum(a.blocked_total for a in self.agvs),     # seconds AGVs spent waiting for each other
            "reroutes": sum(a.reroutes for a in self.agvs),
            "utilization": 100 * statistics.mean(a.busy_time / elapsed for a in self.agvs),
            # average spread (std dev, in seconds) of remaining workload: lower = more even
            "balance": self._balance_sum / self._balance_samples if self._balance_samples else 0.0,
        }


def default_agvs():
    """Same four robots every time, so strategy comparisons start from identical states."""
    return [
        AGV("AGV-01", (3, 5),   BLUE,   speed=2.0, max_load=100, energy_rate=0.5, time_cost=0.30),
        AGV("AGV-02", (14, 6),  GREEN,  speed=3.0, max_load=60,  energy_rate=0.8, time_cost=0.45),
        AGV("AGV-03", (2, 10),  ORANGE, speed=1.5, max_load=150, energy_rate=0.4, time_cost=0.35),
        AGV("AGV-04", (14, 14), PINK,   speed=2.5, max_load=80,  energy_rate=0.6, time_cost=0.40),
    ]


def default_simulation(strategy="Hungarian", weights=None, grid=None):
    return Simulation(grid or Grid.default(), default_agvs(), strategy, weights)
