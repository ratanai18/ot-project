"""Plain data holders: Order and AGV."""
from . import config


class Order:
    def __init__(self, order_id, pickup, delivery, weight, created_at=0.0):
        self.id = order_id
        self.pickup = pickup          # name like "P1"
        self.delivery = delivery      # name like "D2"
        self.weight = weight          # kg
        self.status = "Pending"       # Pending, Assigned, In Progress, Completed, Failed
        self.agv = None               # name of the AGV it is assigned to
        self.created_at = created_at  # simulated seconds
        self.completed_at = None      # simulated seconds


class AGV:
    def __init__(self, name, pos, color, speed, max_load, energy_rate, time_cost):
        self.name = name
        self.pos = pos                # last grid cell the AGV reached
        self.color = color
        self.speed = speed            # cells per second
        self.max_load = max_load      # kg
        self.energy_rate = energy_rate    # energy units per cell when empty
        self.time_cost = time_cost        # rupees per second of working time

        self.status = "Idle"          # Idle, To Pickup, Delivering, Waiting, Yielding
        self.load = 0
        self.order = None             # the order being worked on right now
        self.queue = []               # orders assigned but not started yet
        self.path = []                # cells still to drive through
        self.progress = 0.0           # 0..1 of the way from `pos` to path[0]
        self.wait_left = 0.0
        self.after_wait = None        # "pickup" or "delivery"

        # collision avoidance
        self.reserved = None          # the next cell, reserved while the AGV drives into it
        self.blocked = False          # waiting because the next cell is taken
        self.blocker = None           # the AGV that is in the way
        self.blocked_time = 0.0       # seconds blocked in the current wait
        self.rerouted = False         # already tried another route during this wait
        self.backed_off = False       # already stepped aside during this wait
        self.logged_block = False
        self.last_cell = None         # the cell the AGV came from
        self.side_cell = None         # where it is stepping aside to (to let another AGV pass)
        self.hold = 0.0               # seconds it must stay put after stepping aside

        # statistics
        self.distance = 0.0           # cells driven
        self.empty_distance = 0.0     # cells driven without a package
        self.energy_used = 0.0        # energy units
        self.busy_time = 0.0          # seconds spent working
        self.blocked_total = 0.0      # seconds spent waiting for other AGVs
        self.reroutes = 0
        self.orders_done = 0

    def held(self):
        """How many unfinished orders this AGV is responsible for."""
        return (1 if self.order else 0) + len(self.queue)

    def remaining_cells(self):
        return max(0.0, len(self.path) - self.progress)

    def xy(self):
        """Exact position in grid units (smooth between cells, used for drawing)."""
        if not self.path:
            return float(self.pos[0]), float(self.pos[1])
        nx, ny = self.path[0]
        return (self.pos[0] + (nx - self.pos[0]) * self.progress,
                self.pos[1] + (ny - self.pos[1]) * self.progress)

    def energy_per_cell(self, load):
        """Energy for one cell. Carrying weight costs a bit more."""
        return self.energy_rate * (1 + config.LOAD_ENERGY_FACTOR * load / self.max_load)

    @property
    def operating_cost(self):
        return self.energy_used * config.ENERGY_PRICE + self.busy_time * self.time_cost
