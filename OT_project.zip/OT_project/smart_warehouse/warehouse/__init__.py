"""Smart Warehouse AGV Dispatcher - simulation core (no graphics in here)."""
