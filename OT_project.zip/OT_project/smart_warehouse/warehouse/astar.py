"""A* pathfinding on the warehouse grid (written from scratch)."""
import heapq


def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def astar(grid, start, goal, blocked=()):
    """Return the shortest path as a list of cells [start, ..., goal], or None.

    `blocked` is an optional set of cells to avoid (for example cells other AGVs are standing on).
    The goal itself is never treated as blocked, so a route to an occupied destination still exists.
    """
    if not grid.is_free(start) or not grid.is_free(goal):
        return None
    if start == goal:
        return [start]

    # heap items: (f score, tie-breaker, cell). The tie-breaker keeps heapq
    # from ever having to compare two cells.
    counter = 0
    open_heap = [(manhattan(start, goal), counter, start)]
    came_from = {}
    g_score = {start: 0}
    closed = set()

    while open_heap:
        _, _, current = heapq.heappop(open_heap)
        if current in closed:
            continue
        if current == goal:
            return _build_path(came_from, current)
        closed.add(current)

        for nxt in grid.neighbors(current):
            if nxt in blocked and nxt != goal:
                continue
            new_g = g_score[current] + 1
            if new_g < g_score.get(nxt, float("inf")):
                g_score[nxt] = new_g
                came_from[nxt] = current
                counter += 1
                heapq.heappush(open_heap, (new_g + manhattan(nxt, goal), counter, nxt))

    return None  # goal cannot be reached


def _build_path(came_from, cell):
    path = [cell]
    while cell in came_from:
        cell = came_from[cell]
        path.append(cell)
    path.reverse()
    return path
