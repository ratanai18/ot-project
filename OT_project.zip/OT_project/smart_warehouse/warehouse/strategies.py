"""Three ways to hand pending orders to AGVs.

Every strategy gets the same inputs and returns a list of (agv, order) pairs, at most one
order per AGV. The simulation calls it again until nothing more can be assigned.
    sim     - the simulation (asks "what would it cost if this AGV took this order?")
    orders  - pending orders, oldest first
    agvs    - AGVs that still have room for another order
"""
from .hungarian import hungarian

INFEASIBLE = 1_000_000   # cost used for "this AGV cannot do this order"


def fcfs(sim, orders, agvs):
    """First come, first served: oldest order goes to the AGV that will be free soonest."""
    pairs = []
    free = list(agvs)
    for order in orders:
        options = [(est["W"], i, agv) for i, agv in enumerate(free)
                   if (est := sim.estimate(agv, order))]
        if options:
            agv = min(options, key=lambda o: o[:2])[2]
            pairs.append((agv, order))
            free.remove(agv)
    return pairs


def nearest(sim, orders, agvs):
    """Oldest order first; it goes to the AGV closest to the pickup point (speed is ignored)."""
    pairs = []
    free = list(agvs)
    for order in orders:
        options = [(est["d1"], i, agv) for i, agv in enumerate(free)
                   if (est := sim.estimate(agv, order))]
        if options:
            agv = min(options, key=lambda o: o[:2])[2]
            pairs.append((agv, order))
            free.remove(agv)
    return pairs


def cost_matrix(sim, orders, agvs):
    """C(r, o) = alpha*T + beta*E + gamma*W, with each part scaled to 0..1 first.

    T = estimated completion time of the task (uses the AGV's own speed)
    E = estimated operating cost: energy cost + time-based cost (energy is counted once)
    W = time the AGV still needs to finish what it already holds (workload)
    Empty travel to the pickup is part of both T and E, so it is already in the cost.
    Each part is divided by its largest value in this matrix, so no part wins just
    because it has bigger numbers (seconds vs rupees).
    """
    estimates = [[sim.estimate(agv, order) for agv in agvs] for order in orders]
    usable = [e for row in estimates for e in row if e]
    if not usable:
        return [[INFEASIBLE] * len(agvs) for _ in orders]

    max_t = max(e["T"] for e in usable) or 1.0
    max_e = max(e["E"] for e in usable) or 1.0
    max_w = max(e["W"] for e in usable) or 1.0
    w = sim.weights
    return [[INFEASIBLE if e is None else
             w["alpha"] * e["T"] / max_t + w["beta"] * e["E"] / max_e + w["gamma"] * e["W"] / max_w
             for e in row] for row in estimates]


def hungarian_assign(sim, orders, agvs):
    """Let the Hungarian algorithm pick the cheapest overall matching of orders to AGVs.

    More orders than AGVs (or the other way round) is fine: only the best
    min(orders, AGVs) pairs are made, the rest wait for the next round.
    """
    matrix = cost_matrix(sim, orders, agvs)
    pairs = []
    for r, c in hungarian(matrix):
        if matrix[r][c] < INFEASIBLE:        # drop pairs forced onto an impossible job
            pairs.append((agvs[c], orders[r]))
    return pairs


STRATEGY_FUNCTIONS = {"FCFS": fcfs, "Nearest": nearest, "Hungarian": hungarian_assign}


def assign(name, sim, orders, agvs):
    return STRATEGY_FUNCTIONS[name](sim, orders, agvs)
