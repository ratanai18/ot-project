"""Start the dashboard:   python main.py"""
from dashboard import main

if __name__ == "__main__":
    main()
